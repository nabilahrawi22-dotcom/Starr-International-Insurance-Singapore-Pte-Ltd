import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { m as cn, n as Button, p as TRAVEL_PLANS, s as LINES } from "./site-shell-B9nyQ5YX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quote-forms-BXtxURDJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md border border-line bg-paper px-3 text-base text-ink shadow-none outline-none transition-colors duration-150 placeholder:text-muted/80 focus:border-navy focus:ring-2 focus:ring-navy/15", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-32 w-full rounded-lg border border-line bg-paper px-3 py-3 text-base text-ink outline-none transition-colors duration-150 placeholder:text-muted/80 focus:border-navy focus:ring-2 focus:ring-navy/15", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("mb-1.5 block text-sm font-medium text-ink", className),
		...props
	});
}
function FieldError({ children }) {
	if (!children) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm text-danger",
		children
	});
}
function Select({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn("h-11 w-full rounded-md border border-line bg-paper px-3 text-base text-ink outline-none transition-colors duration-150 focus:border-navy focus:ring-2 focus:ring-navy/15", className),
		...props,
		children
	});
}
var KEY = "starr-sg-enquiries";
function readAll() {
	if (typeof window === "undefined") return [];
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function saveEnquiry(kind, payload) {
	const enquiry = {
		id: `SG${Date.now().toString(36).toUpperCase()}`,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		kind,
		payload
	};
	const next = [enquiry, ...readAll()].slice(0, 40);
	localStorage.setItem(KEY, JSON.stringify(next));
	return enquiry;
}
function SuccessPanel({ children, className }) {
	const el = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		el.current?.scrollIntoView({
			behavior: "smooth",
			block: "center"
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: el,
		className,
		children
	});
}
var REGIONS = [
	{
		id: "asean",
		label: "ASEAN",
		factor: 1
	},
	{
		id: "asia",
		label: "Asia (ex-Japan)",
		factor: 1.15
	},
	{
		id: "worldwide",
		label: "Worldwide excluding USA / Canada",
		factor: 1.45
	},
	{
		id: "usa",
		label: "Worldwide including USA / Canada",
		factor: 1.85
	}
];
function formatSgd(value) {
	return new Intl.NumberFormat("en-SG", {
		style: "currency",
		currency: "SGD",
		maximumFractionDigits: 0
	}).format(Math.round(value));
}
function TravelQuoteForm({ compact = false }) {
	const [trip, setTrip] = (0, import_react.useState)("single");
	const [region, setRegion] = (0, import_react.useState)(REGIONS[0].id);
	const [travellers, setTravellers] = (0, import_react.useState)(1);
	const [days, setDays] = (0, import_react.useState)(7);
	const [planId, setPlanId] = (0, import_react.useState)("premier");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [ref, setRef] = (0, import_react.useState)(null);
	const estimate = (0, import_react.useMemo)(() => {
		const regionFactor = REGIONS.find((r) => r.id === region)?.factor ?? 1;
		const plan = TRAVEL_PLANS.find((p) => p.id === planId) ?? TRAVEL_PLANS[1];
		const base = trip === "annual" ? 188 : 52;
		const durationFactor = trip === "annual" ? 1 : .75 + Math.min(days, 180) / 120;
		const peopleFactor = 1 + Math.max(0, travellers - 1) * .72;
		return base * regionFactor * plan.multiplier * durationFactor * peopleFactor;
	}, [
		trip,
		region,
		travellers,
		days,
		planId
	]);
	function submit(e) {
		e.preventDefault();
		const next = {};
		if (!name.trim()) next.name = "Please enter your name.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email.";
		if (phone.replace(/\D/g, "").length < 8) next.phone = "Enter a contact number.";
		setErrors(next);
		if (Object.keys(next).length) return;
		const enquiry = saveEnquiry("travel", {
			trip,
			region,
			travellers: String(travellers),
			days: String(days),
			plan: planId,
			estimate: formatSgd(estimate),
			name: name.trim(),
			email: email.trim(),
			phone: phone.trim()
		});
		setRef(enquiry.id);
		toast.success(`Quotation request ${enquiry.id} received.`);
	}
	if (ref) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SuccessPanel, {
		className: "rounded-xl bg-navy p-8 text-ivory shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.24em] text-ivory/60",
				children: "Request received"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-display text-3xl",
				children: "Thank you. We have your details."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-ivory/80",
				children: [
					"Reference ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-ivory",
						children: ref
					}),
					". A member of the Singapore team will follow up with a formal quotation. The illustrated premium of",
					" ",
					formatSgd(estimate),
					" is indicative only and is not an offer to bind."
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-xs font-medium uppercase tracking-[0.22em] text-muted",
					children: "Trip type"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [["single", "Single trip"], ["annual", "Annual multi-trip"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTrip(id),
						className: cn("h-12 rounded-md border text-sm font-medium transition-colors duration-150", trip === id ? "border-navy bg-navy text-ivory" : "border-line bg-paper text-ink hover:border-navy"),
						children: label
					}, id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("grid gap-5", compact ? "md:grid-cols-2" : "md:grid-cols-3"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "region",
						children: "Destination"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						id: "region",
						value: region,
						onChange: (e) => setRegion(e.target.value),
						children: REGIONS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: r.id,
							children: r.label
						}, r.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "travellers",
						children: "Travellers"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						id: "travellers",
						value: String(travellers),
						onChange: (e) => setTravellers(Number(e.target.value)),
						children: [
							1,
							2,
							3,
							4,
							5,
							6
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: n,
							children: n
						}, n))
					})] }),
					trip === "single" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "days",
						children: "Duration (days)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "days",
						type: "number",
						min: 1,
						max: 180,
						value: days,
						onChange: (e) => setDays(Number(e.target.value) || 1)
					})] }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "mb-3 text-xs font-medium uppercase tracking-[0.22em] text-muted",
				children: "Plan"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-3",
				children: TRAVEL_PLANS.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setPlanId(plan.id),
					className: cn("rounded-xl border p-5 text-left transition-shadow duration-150", planId === plan.id ? "border-navy bg-navy text-ivory shadow-lift" : "border-line bg-paper text-ink hover:shadow-card"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl",
						children: plan.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: cn("mt-2 text-sm leading-relaxed", planId === plan.id ? "text-ivory/75" : "text-muted"),
						children: ["Medical ", plan.medical]
					})]
				}, plan.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col justify-between gap-4 rounded-xl bg-ivory p-6 md:flex-row md:items-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.22em] text-muted",
						children: "Indicative premium"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-4xl text-navy",
						children: formatSgd(estimate)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-md text-sm text-muted",
						children: "Illustration only — not a quotation or an offer to bind. Final terms follow underwriting and the policy wording."
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "tq-name",
							children: "Full name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "tq-name",
							value: name,
							onChange: (e) => setName(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.name })
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "tq-email",
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "tq-email",
							type: "email",
							value: email,
							onChange: (e) => setEmail(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.email })
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "tq-phone",
							children: "Phone"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "tq-phone",
							type: "tel",
							value: phone,
							onChange: (e) => setPhone(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.phone })
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "lg",
				children: "Request a formal quotation"
			})
		]
	});
}
function CommercialQuoteForm() {
	const [line, setLine] = (0, import_react.useState)(LINES[0].slug);
	const [company, setCompany] = (0, import_react.useState)("");
	const [turnover, setTurnover] = (0, import_react.useState)("25-100");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [ref, setRef] = (0, import_react.useState)(null);
	function submit(e) {
		e.preventDefault();
		const next = {};
		if (!company.trim()) next.company = "Company name is required.";
		if (!name.trim()) next.name = "Please enter a contact name.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email.";
		setErrors(next);
		if (Object.keys(next).length) return;
		const enquiry = saveEnquiry("commercial", {
			line,
			company: company.trim(),
			turnover,
			name: name.trim(),
			email: email.trim(),
			phone: phone.trim(),
			notes: notes.trim()
		});
		setRef(enquiry.id);
		toast.success(`Broker enquiry ${enquiry.id} received.`);
	}
	if (ref) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SuccessPanel, {
		className: "rounded-xl bg-navy p-8 text-ivory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.24em] text-ivory/60",
				children: "Enquiry received"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-display text-3xl",
				children: "Your submission is with our underwriters."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-ivory/80",
				children: [
					"Reference ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-ivory",
						children: ref
					}),
					". We typically respond through the placing broker. This is not a bindable indication."
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "line",
					children: "Line of business"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					id: "line",
					value: line,
					onChange: (e) => setLine(e.target.value),
					children: LINES.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: l.slug,
						children: l.title
					}, l.slug))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "turnover",
					children: "Approximate turnover (SGD)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					id: "turnover",
					value: turnover,
					onChange: (e) => setTurnover(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "under-25",
							children: "Under 25 million"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "25-100",
							children: "25 – 100 million"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "100-500",
							children: "100 – 500 million"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "500+",
							children: "Over 500 million"
						})
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "company",
					children: "Company / insured"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "company",
					value: company,
					onChange: (e) => setCompany(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.company })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cq-name",
							children: "Contact name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "cq-name",
							value: name,
							onChange: (e) => setName(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.name })
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cq-email",
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "cq-email",
							type: "email",
							value: email,
							onChange: (e) => setEmail(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.email })
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "cq-phone",
						children: "Phone"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "cq-phone",
						type: "tel",
						value: phone,
						onChange: (e) => setPhone(e.target.value)
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: "notes",
				children: "Risk notes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				id: "notes",
				value: notes,
				onChange: (e) => setNotes(e.target.value),
				placeholder: "Occupancy, geography, current programme, target inception…"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "lg",
				children: "Submit to underwriting"
			})
		]
	});
}
function ContactForm() {
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [topic, setTopic] = (0, import_react.useState)("general");
	const [message, setMessage] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [ref, setRef] = (0, import_react.useState)(null);
	function submit(e) {
		e.preventDefault();
		const next = {};
		if (!name.trim()) next.name = "Please enter your name.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email.";
		if (message.trim().length < 10) next.message = "Please tell us a little more.";
		setErrors(next);
		if (Object.keys(next).length) return;
		const enquiry = saveEnquiry("general", {
			name: name.trim(),
			email: email.trim(),
			topic,
			message: message.trim()
		});
		setRef(enquiry.id);
		toast.success(`Message ${enquiry.id} sent.`);
	}
	if (ref) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SuccessPanel, {
		className: "rounded-xl border border-line bg-ivory p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.22em] text-muted",
				children: "Message received"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 font-display text-3xl text-navy",
				children: "We will be in touch."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-muted",
				children: [
					"Reference ",
					ref,
					". During business hours we aim to respond the same day."
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "c-name",
						children: "Name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "c-name",
						value: name,
						onChange: (e) => setName(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.name })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "c-email",
						children: "Email"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "c-email",
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.email })
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: "topic",
				children: "Topic"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				id: "topic",
				value: topic,
				onChange: (e) => setTopic(e.target.value),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "general",
						children: "General enquiry"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "policy",
						children: "Existing policy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "broker",
						children: "Broker / placing"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "media",
						children: "Media and public disclosure"
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "message",
					children: "Message"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "message",
					value: message,
					onChange: (e) => setMessage(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.message })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "lg",
				children: "Send message"
			})
		]
	});
}
function ClaimForm() {
	const [kind, setKind] = (0, import_react.useState)("travel");
	const [policy, setPolicy] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [incident, setIncident] = (0, import_react.useState)("");
	const [docs, setDocs] = (0, import_react.useState)([]);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [ref, setRef] = (0, import_react.useState)(null);
	function toggleDoc(id) {
		setDocs((prev) => prev.includes(id) ? prev.filter((d) => d !== id) : [...prev, id]);
	}
	function submit(e) {
		e.preventDefault();
		const next = {};
		if (!name.trim()) next.name = "Please enter your name.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email.";
		if (incident.trim().length < 12) next.incident = "Please describe what happened.";
		setErrors(next);
		if (Object.keys(next).length) return;
		const enquiry = saveEnquiry("claim", {
			kind,
			policy: policy.trim(),
			name: name.trim(),
			email: email.trim(),
			phone: phone.trim(),
			incident: incident.trim(),
			docs: docs.join(", ")
		});
		setRef(enquiry.id);
		toast.success(`Claim notice ${enquiry.id} recorded.`);
	}
	if (ref) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SuccessPanel, {
		className: "rounded-xl bg-navy p-8 text-ivory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.24em] text-ivory/60",
				children: "Notice recorded"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-display text-3xl",
				children: "Your claim notice is with us."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 leading-relaxed text-ivory/80",
				children: [
					"Reference ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-ivory",
						children: ref
					}),
					". Please keep original documents. A handler will contact you to complete the formal claim. For travel medical emergencies still in progress, call the 24-hour assistance line immediately."
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "kind",
					children: "Claim type"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					id: "kind",
					value: kind,
					onChange: (e) => setKind(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "travel",
							children: "Travel (Travelead)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "accident",
							children: "Accident & Health"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "property",
							children: "Property / technical"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "liability",
							children: "Casualty / financial lines"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "marine",
							children: "Marine"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "construction",
							children: "Construction"
						})
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "policy",
					children: "Policy or certificate number (if known)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "policy",
					value: policy,
					onChange: (e) => setPolicy(e.target.value)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cl-name",
							children: "Name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "cl-name",
							value: name,
							onChange: (e) => setName(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.name })
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cl-email",
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "cl-email",
							type: "email",
							value: email,
							onChange: (e) => setEmail(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.email })
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "cl-phone",
						children: "Phone"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "cl-phone",
						type: "tel",
						value: phone,
						onChange: (e) => setPhone(e.target.value)
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "incident",
					children: "What happened"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "incident",
					value: incident,
					onChange: (e) => setIncident(e.target.value),
					placeholder: "Date, place, what occurred, and any third parties involved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: errors.incident })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "mb-3 text-sm font-medium text-ink",
				children: "Documents you can provide"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2 md:grid-cols-2",
				children: [
					["id", "Identification / policy number"],
					["medical", "Medical reports and invoices"],
					["police", "Police or incident report"],
					["travel", "Tickets and boarding passes"],
					["receipts", "Receipts or repair quotes"],
					["photos", "Photographs"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 cursor-pointer items-center gap-3 rounded-md border border-line bg-paper px-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: docs.includes(id),
						onChange: () => toggleDoc(id),
						className: "size-4 accent-navy"
					}), label]
				}) }, id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "lg",
				children: "Submit notice of claim"
			})
		]
	});
}
//#endregion
export { TravelQuoteForm as i, CommercialQuoteForm as n, ContactForm as r, ClaimForm as t };
