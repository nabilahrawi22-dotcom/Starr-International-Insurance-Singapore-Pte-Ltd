import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as MapPin, o as Mail, r as Phone, s as Clock } from "../_libs/lucide-react.mjs";
import { a as COMPANY, c as PageHero, u as SiteShell } from "./site-shell-B9nyQ5YX.mjs";
import { r as ContactForm } from "./quote-forms-BXtxURDJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-BhdYJKYf.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Contact",
			title: "CapitaGreen, seventh floor.",
			lede: "138 Market Street is a corporate underwriting office. Appointments are preferred; travel and claims support is available by phone and email during business hours.",
			image: "/images/hero-capitagreen.jpg",
			imageAlt: "CapitaGreen at dusk in Raffles Place"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl gap-12 px-6 py-16 md:grid-cols-2 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl text-navy",
				children: "Singapore office"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-8 space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
							className: "mt-1 size-5 shrink-0 text-navy",
							strokeWidth: 1.5
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-ink",
								children: COMPANY.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: COMPANY.addressLines.join(", ")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: COMPANY.mapsUrl,
								target: "_blank",
								rel: "noreferrer",
								className: "mt-1 inline-block text-sm font-medium text-navy",
								children: "Get directions"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
							className: "mt-1 size-5 shrink-0 text-navy",
							strokeWidth: 1.5
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Switchboard"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: COMPANY.phoneHref,
								className: "font-medium text-ink",
								children: COMPANY.phoneDisplay
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Customer service"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: COMPANY.csPhoneHref,
								className: "font-medium text-ink",
								children: COMPANY.csPhoneDisplay
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "24-hour assistance"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: COMPANY.emergencyHref,
								className: "font-medium text-ink",
								children: COMPANY.emergencyDisplay
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
							className: "mt-1 size-5 shrink-0 text-navy",
							strokeWidth: 1.5
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `mailto:${COMPANY.email}`,
							className: "font-medium text-ink",
							children: COMPANY.email
						}) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {
							className: "mt-1 size-5 shrink-0 text-navy",
							strokeWidth: 1.5
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-ink",
							children: COMPANY.hours
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: COMPANY.hoursNote
						})] })]
					})
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-ivory p-6 md:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl text-navy",
						children: "Write to us"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 mb-8 text-sm text-muted",
						children: "For placing business, please copy your broker. For an existing claim, use the claims notice so it reaches a handler with a reference number."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactForm, {})
				]
			})]
		})]
	}) });
}
//#endregion
export { ContactPage as component };
