import { C as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as ArrowRight, r as Phone } from "../_libs/lucide-react.mjs";
import { a as COMPANY, l as STATS, n as Button, s as LINES, u as SiteShell } from "./site-shell-B9nyQ5YX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Br80W3ky.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative isolate min-h-[36rem] overflow-hidden bg-navy text-ivory md:min-h-[42rem]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/hero-capitagreen.jpg",
						alt: "CapitaGreen in Singapore’s Raffles Place at dusk",
						className: "absolute inset-0 size-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-navy-deep/94 via-navy-deep/78 to-navy/35" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto flex min-h-[36rem] max-w-6xl flex-col justify-end px-6 py-20 md:min-h-[42rem]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-[0.28em] text-ivory/70",
								children: "Singapore · CapitaGreen"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-4 max-w-3xl font-display text-5xl font-medium text-ivory md:text-7xl",
								children: "Meet the moment with specialty insurance."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-6 max-w-xl text-lg leading-relaxed text-ivory/80",
								children: [COMPANY.shortName, " underwrites accident & health, casualty, financial lines, construction, technical risks and marine — with local expertise and Starr’s global capacity behind every risk."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "inverse",
									size: "lg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/quote",
										children: "Request a quotation"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "ghost",
									size: "lg",
									className: "border border-ivory/30",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/travel",
										children: "Travelead travel cover"
									})
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-b border-line bg-navy text-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-6xl grid-cols-2 gap-8 px-6 py-10 md:grid-cols-4",
					children: STATS.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl text-ivory md:text-5xl",
						children: stat.value
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-ivory/65",
						children: stat.label
					})] }, stat.label))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 md:grid-cols-2 md:py-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.24em] text-muted",
						children: "The house"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl text-navy md:text-5xl",
						children: "A licensed Singapore insurer, not a storefront."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-lg leading-relaxed text-muted",
						children: "We operate from the seventh floor of CapitaGreen as a MAS-licensed Direct Insurer (General). Commercial programmes are placed through brokers. Individuals come to us for Travelead travel insurance, claims support and 24-hour emergency assistance."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 leading-relaxed text-muted",
						children: "The Singapore office is also Starr’s hub for Labuan, Korea and GIFT City branches — underwriting, claims and management for a growing Asia-Pacific network."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "mt-8",
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/about",
							children: ["About Starr Singapore ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/team.jpg",
					alt: "Starr colleagues in a contemporary office reception",
					className: "img-frame aspect-video w-full rounded-xl object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
					className: "mt-3 text-sm text-muted",
					children: "Underwriting, claims and management — a specialist team, not a retail counter."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-6 py-20 md:py-28",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-between gap-6 md:flex-row md:items-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.24em] text-muted",
							children: "Lines of business"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 max-w-xl font-display text-4xl text-navy md:text-5xl",
							children: "Specialty cover, written with discipline."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/solutions",
							className: "inline-flex min-h-11 items-center gap-2 text-sm font-medium text-navy",
							children: ["View all solutions ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
						children: LINES.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/solutions/$slug",
							params: { slug: line.slug },
							className: "group overflow-hidden rounded-xl bg-paper shadow-card transition-shadow duration-200 hover:shadow-lift",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "aspect-video overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: line.image,
									alt: line.imageAlt,
									className: "size-full object-cover transition-transform duration-500 group-hover:scale-105"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs tracking-[0.2em] text-muted",
										children: line.number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 font-display text-2xl text-navy",
										children: line.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted",
										children: line.short
									})
								]
							})]
						}, line.slug))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative isolate overflow-hidden bg-navy text-ivory",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/travel.jpg",
						alt: "Traveller watching a departure at dawn",
						className: "absolute inset-0 size-full object-cover opacity-50"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-navy-deep/70" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto grid max-w-6xl gap-10 px-6 py-20 md:grid-cols-2 md:items-center md:py-28",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-[0.24em] text-ivory/65",
								children: "For travellers"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-4xl md:text-5xl",
								children: "Travelead travel insurance"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-5 text-lg leading-relaxed text-ivory/80",
								children: [
									"Single-trip cover with no enrolment age limit. Annual plans to age 70. No co-payment on selected plans, amateur hazardous sports included, and 24-hour global assistance on ",
									COMPANY.emergencyDisplay,
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "inverse",
									size: "lg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/travel",
										children: "Compare plans"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "ghost",
									size: "lg",
									className: "border border-ivory/30",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/claims",
										children: "How to claim"
									})
								})]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-4 text-sm text-ivory/85",
							children: [
								"Medical expenses without outpatient visit sublimits",
								"Follow-up treatment in Singapore within 30 days of return",
								"Children under 18 travelling alone can be covered",
								"Written notice of claim within 30 days of the event"
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-t border-ivory/20 pt-4",
								children: item
							}, item))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-6xl gap-10 px-6 py-20 md:grid-cols-2 md:py-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.24em] text-muted",
						children: "CapitaGreen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl text-navy",
						children: "Speak with the Singapore office"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 leading-relaxed text-muted",
						children: "Brokers, risk managers and policyholders — the same address, two paths. Commercial placing through professional intermediaries; travel and claims with a direct customer service desk."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("address", {
						className: "mt-6 not-italic text-ink",
						children: COMPANY.addressLines.join(", ")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: COMPANY.hours
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: COMPANY.phoneHref,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }),
									" ",
									COMPANY.phoneDisplay
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/contact",
								children: "Contact & hours"
							})
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/skyline.jpg",
					alt: "Marina Bay and Raffles Place at dusk",
					className: "img-frame h-full min-h-72 w-full rounded-xl object-cover"
				})]
			})
		]
	}) });
}
//#endregion
export { Home as component };
