import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as PageHero, m as cn, u as SiteShell } from "./site-shell-B9nyQ5YX.mjs";
import { i as TravelQuoteForm, n as CommercialQuoteForm } from "./quote-forms-BXtxURDJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quote-BzthpP2h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuotePage() {
	const [tab, setTab] = (0, import_react.useState)("travel");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Quotations",
			title: "Tell us the risk. We will tell you if it is ours to write.",
			lede: "Travel quotations for individuals. Commercial submissions through — or copied to — your broker. Nothing on this page is an offer to bind.",
			image: "/images/boardroom.jpg",
			imageAlt: "Boardroom in late afternoon light",
			compact: true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-6 py-16 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-3",
				children: [["travel", "Travel"], ["commercial", "Commercial / broker"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(id),
					className: cn("h-11 rounded-md px-5 text-sm font-medium transition-colors duration-150", tab === id ? "bg-navy text-ivory" : "border border-line bg-paper text-ink"),
					children: label
				}, id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 rounded-xl bg-ivory p-6 md:p-10",
				children: tab === "travel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TravelQuoteForm, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommercialQuoteForm, {})
			})]
		})]
	}) });
}
//#endregion
export { QuotePage as component };
