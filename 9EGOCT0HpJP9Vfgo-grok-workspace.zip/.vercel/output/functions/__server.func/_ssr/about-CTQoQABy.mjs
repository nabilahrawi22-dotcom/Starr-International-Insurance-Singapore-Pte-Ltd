import { C as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as COMPANY, c as PageHero, l as STATS, n as Button, o as GOVERNANCE, t as APAC, u as SiteShell } from "./site-shell-B9nyQ5YX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-CTQoQABy.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
				eyebrow: "Who we are",
				title: "A Singapore insurer in a global specialty house.",
				lede: "Starr International Insurance (Singapore) Pte. Ltd. is a wholly owned subsidiary of Starr Insurance & Reinsurance Limited, itself an indirect subsidiary of Starr International Company, Inc.",
				image: "/images/skyline.jpg",
				imageAlt: "Singapore financial district at dusk"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-6xl items-start gap-12 px-6 py-20 md:grid-cols-2 md:py-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.24em] text-muted",
						children: "Mandate"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl text-navy",
						children: "Underwriting profitability, not volume for its own sake."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 leading-relaxed text-muted",
						children: "The Singapore company’s strategic objective is sustained profitability and capital efficiency. That means a balanced book, underwriting guidelines that are actually followed, prudent claims provisions, and reinsurers chosen for security rather than price alone."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 leading-relaxed text-muted",
						children: "We are licensed by the Monetary Authority of Singapore as a Direct Insurer (General). The office at 138 Market Street, #07-04 CapitaGreen, houses local underwriting, claims and management — and supports overseas branches in Labuan, Seoul and GIFT City."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-navy p-8 text-ivory md:p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.24em] text-ivory/60",
							children: "Leadership"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-3xl",
							children: COMPANY.ceo
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-ivory/70",
							children: "Chief Executive, Singapore"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 leading-relaxed text-ivory/80",
							children: [
								"The Singapore operation is led by ",
								COMPANY.ceo,
								", as recorded in the MAS financial institutions directory. The Chairman and Chief Executive are separate offices. A Senior Management Committee covers underwriting, claims, finance, legal and compliance, risk, technology and people."
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 md:grid-cols-2 md:py-28",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/leadership.jpg",
						alt: "Starr Insurance corporate leadership",
						className: "img-frame w-full rounded-xl object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.24em] text-muted",
							children: "Starr group"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-4xl text-navy",
							children: "A century of specialty insurance, written locally."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 leading-relaxed text-muted",
							children: "Starr traces its heritage to C.V. Starr’s founding of an insurance agency in Shanghai in 1919. Today the group writes in more than 170 countries, with an innovation mindset, an agile approach, and local teams wherever clients operate."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 leading-relaxed text-muted",
							children: "Starr International Insurance (Singapore) Pte. Ltd. carries an A.M. Best rating of “A” (Excellent), Financial Size Category XV — the same financial strength designation as Starr’s other principal carriers."
						})
					] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-6 py-20 md:py-28",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.24em] text-muted",
						children: "Governance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 max-w-2xl font-display text-4xl text-navy",
						children: "Board oversight, internal control, enterprise risk."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-6 md:grid-cols-2",
						children: GOVERNANCE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-xl border border-line bg-paper p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl text-navy",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 leading-relaxed text-muted",
								children: item.body
							})]
						}, item.title))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-line bg-navy text-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-6xl grid-cols-2 gap-8 px-6 py-12 md:grid-cols-4",
					children: STATS.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl",
						children: stat.value
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-ivory/65",
						children: stat.label
					})] }, stat.label))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-6 py-20 md:py-28",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.24em] text-muted",
						children: "Asia-Pacific"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl text-navy",
						children: "A regional network from Singapore"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
						children: APAC.map((office) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-ivory px-5 py-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl text-navy",
								children: office.city
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: office.role
							})]
						}, office.city))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-10 max-w-2xl text-sm leading-relaxed text-muted",
						children: "For the financial year ended 31 December 2025, insurance revenue was approximately USD 424 million. The insurance service result was around USD 44 million. These figures are drawn from the company’s public disclosure and are presented here for context, not as a solicitation."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "mt-8",
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							children: "Contact the Singapore office"
						})
					})
				]
			})
		]
	}) });
}
//#endregion
export { AboutPage as component };
