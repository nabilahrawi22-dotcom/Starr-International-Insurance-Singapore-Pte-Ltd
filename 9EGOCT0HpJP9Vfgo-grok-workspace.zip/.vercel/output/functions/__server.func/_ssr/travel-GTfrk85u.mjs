import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as COMPANY, c as PageHero, d as TRAVEL_FAQS, f as TRAVEL_FEATURES, m as cn, p as TRAVEL_PLANS, u as SiteShell } from "./site-shell-B9nyQ5YX.mjs";
import { i as TravelQuoteForm } from "./quote-forms-BXtxURDJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/travel-GTfrk85u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TravelPage() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
				eyebrow: "Travelead",
				title: "Travel insurance, written with honesty and a clear schedule.",
				lede: "Single-trip or annual. Medical, cancellation, baggage and 24-hour assistance — with no co-payment on selected plans.",
				image: "/images/travel.jpg",
				imageAlt: "Traveller at the window as a flight departs"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-b border-line bg-navy text-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-3 px-6 py-5 md:flex-row md:items-center md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"24-hour Global Emergency Assistance ·",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: COMPANY.emergencyHref,
								className: "font-medium text-ivory underline-offset-4 hover:underline",
								children: COMPANY.emergencyDisplay
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-ivory/70",
						children: ["Customer service ", COMPANY.csPhoneDisplay]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-6 py-16 md:py-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.24em] text-muted",
						children: "Why Travelead"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 max-w-2xl font-display text-4xl text-navy",
						children: "Built for how people actually travel from Singapore."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
						children: TRAVEL_FEATURES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-xl bg-ivory p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl text-navy",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: item.body
							})]
						}, item.title))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-6 py-16 md:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl text-navy",
							children: "Compare plans"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-2xl text-muted",
							children: "Benefit amounts below illustrate typical Travelead-style schedules. Your issued policy wording and schedule of benefits prevail. Premiums in the illustrator are indicative only."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 overflow-x-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-3xl border-collapse text-left text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-line",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-4 pr-4 font-medium text-muted",
										children: "Benefit"
									}), TRAVEL_PLANS.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-4 font-display text-xl font-medium text-navy",
										children: plan.name
									}, plan.id))]
								}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [
									["Medical expenses", "medical"],
									["Trip cancellation", "cancellation"],
									["Baggage", "baggage"],
									["Personal accident", "personalAccident"],
									["Sports", "sports"]
								].map(([label, key]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-line",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-4 pr-4 text-muted",
										children: label
									}), TRAVEL_PLANS.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-4 text-ink",
										children: plan[key]
									}, plan.id))]
								}, key)) })]
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-6 py-16 md:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl text-navy",
							children: "Illustrate a premium, then request a quote"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-2xl text-muted",
							children: "Choose trip type, destination and plan. We will send a formal quotation — nothing on this page binds cover."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 rounded-xl bg-paper p-6 shadow-card md:p-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TravelQuoteForm, {})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-3xl px-6 py-16 md:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl text-navy",
					children: "Questions"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 divide-y divide-line border-y border-line",
					children: TRAVEL_FAQS.map((faq, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex min-h-14 w-full items-center justify-between gap-4 py-4 text-left",
						"aria-expanded": open === i,
						onClick: () => setOpen(open === i ? null : i),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-navy",
							children: faq.q
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-muted", open === i && "text-navy"),
							children: open === i ? "−" : "+"
						})]
					}), open === i ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pb-5 leading-relaxed text-muted",
						children: faq.a
					}) : null] }, faq.q))
				})]
			})
		]
	}) });
}
//#endregion
export { TravelPage as component };
