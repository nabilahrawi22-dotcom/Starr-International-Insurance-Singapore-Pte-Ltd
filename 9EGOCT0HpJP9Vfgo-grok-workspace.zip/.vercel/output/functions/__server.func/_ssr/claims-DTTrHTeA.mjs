import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Phone } from "../_libs/lucide-react.mjs";
import { a as COMPANY, c as PageHero, i as CLAIM_STEPS, n as Button, r as CLAIM_DOCS, u as SiteShell } from "./site-shell-B9nyQ5YX.mjs";
import { t as ClaimForm } from "./quote-forms-BXtxURDJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/claims-DTTrHTeA.js
var import_jsx_runtime = require_jsx_runtime();
function ClaimsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
				eyebrow: "Claims",
				title: "When something happens, start with people. Then notify us.",
				lede: "Written notice within 30 days. Original documents. A handler who will tell you what happens next.",
				image: "/images/health.jpg",
				imageAlt: "Quiet medical atrium"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-navy text-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-4 px-6 py-8 md:flex-row md:items-center md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.22em] text-ivory/60",
							children: "Emergency"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-3xl",
							children: "24-hour global assistance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-ivory/75",
							children: "Travel, medical, evacuation, repatriation, hospital admission guarantee."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "inverse",
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: COMPANY.emergencyHref,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }),
								" ",
								COMPANY.emergencyDisplay
							]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-6 py-16 md:py-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl text-navy",
					children: "How a claim proceeds"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-12 grid gap-6 md:grid-cols-2",
					children: CLAIM_STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl border border-line bg-paper p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-[0.22em] text-muted",
								children: step.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-display text-2xl text-navy",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 leading-relaxed text-muted",
								children: step.body
							})
						]
					}, step.n))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-12 px-6 py-16 md:grid-cols-2 md:py-24",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl text-navy",
							children: "Documents that help"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 leading-relaxed text-muted",
							children: "You do not need every item before you notify us. Tick what you already have — we will request the rest."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 space-y-3",
							children: CLAIM_DOCS.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-t border-line pt-3 text-sm text-ink",
								children: doc.label
							}, doc.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-8 text-sm text-muted",
							children: [
								"Customer service ",
								COMPANY.csPhoneDisplay,
								" · ",
								COMPANY.email,
								" · ",
								COMPANY.hours
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-paper p-6 shadow-card md:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-3xl text-navy",
								children: "Notice of claim"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 mb-8 text-sm text-muted",
								children: "This records a notice with the Singapore office. It does not replace a completed claim form or original evidence."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimForm, {})
						]
					})]
				})
			})
		]
	}) });
}
//#endregion
export { ClaimsPage as component };
