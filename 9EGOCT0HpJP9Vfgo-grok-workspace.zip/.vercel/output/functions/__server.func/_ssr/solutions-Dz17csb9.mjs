import { C as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as PageHero, n as Button, s as LINES, u as SiteShell } from "./site-shell-B9nyQ5YX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/solutions-Dz17csb9.js
var import_jsx_runtime = require_jsx_runtime();
function SolutionsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		id: "main",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			eyebrow: "Solutions",
			title: "Six specialty lines. One underwriting standard.",
			lede: "Accident & Health, Casualty, Financial Lines, Construction, Technical Risks and Marine — written from Singapore for risks that need more than a commodity wording.",
			image: "/images/boardroom.jpg",
			imageAlt: "Boardroom overlooking the Singapore CBD"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-6 py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-16",
				children: LINES.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "grid items-center gap-8 md:grid-cols-2 md:gap-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: line.image,
						alt: line.imageAlt,
						className: `img-frame aspect-video w-full rounded-xl object-cover ${index % 2 === 1 ? "md:order-2" : ""}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: index % 2 === 1 ? "md:order-1" : "",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-[0.22em] text-muted",
								children: line.number
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 font-display text-4xl text-navy",
								children: line.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 leading-relaxed text-muted",
								children: line.summary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "mt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/solutions/$slug",
									params: { slug: line.slug },
									children: "Read this line"
								})
							})
						]
					})]
				}, line.slug))
			})
		})]
	}) });
}
//#endregion
export { SolutionsPage as component };
