//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dl9KvtiK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/claims",
			"/contact",
			"/quote",
			"/solutions",
			"/travel"
		],
		preloads: ["/assets/index-B3wLASfF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B3wLASfF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DvWdlSIt.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-CA2fxwp1.js"]
	},
	"/claims": {
		filePath: "/workspace/src/routes/claims.tsx",
		children: void 0,
		preloads: ["/assets/claims-BpQ-mG5z.js", "/assets/quote-forms-CxKQpNPR.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-BpT7U7-p.js", "/assets/quote-forms-CxKQpNPR.js"]
	},
	"/quote": {
		filePath: "/workspace/src/routes/quote.tsx",
		children: void 0,
		preloads: ["/assets/quote-CqOyXp4C.js", "/assets/quote-forms-CxKQpNPR.js"]
	},
	"/solutions": {
		filePath: "/workspace/src/routes/solutions.tsx",
		children: ["/solutions/$slug"],
		preloads: ["/assets/solutions-BOTAmxvT.js"]
	},
	"/travel": {
		filePath: "/workspace/src/routes/travel.tsx",
		children: void 0,
		preloads: ["/assets/travel-32VRONOQ.js", "/assets/quote-forms-CxKQpNPR.js"]
	},
	"/solutions/$slug": {
		filePath: "/workspace/src/routes/solutions.$slug.tsx",
		children: void 0,
		preloads: ["/assets/solutions._slug-C9UwqIOX.js"]
	}
} });
//#endregion
export { tsrStartManifest };
