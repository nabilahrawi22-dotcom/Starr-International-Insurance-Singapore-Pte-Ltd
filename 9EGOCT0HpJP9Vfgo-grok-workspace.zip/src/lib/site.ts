export const COMPANY = {
  name: "Starr International Insurance (Singapore) Pte. Ltd.",
  shortName: "Starr Insurance Singapore",
  wordmark: "STARR",
  tagline: "Specialty insurance. Singapore underwriting. Global capacity.",
  addressLines: ["138 Market Street", "#07-04 CapitaGreen", "Singapore 048946"],
  mapsUrl:
    "https://www.google.com/maps/search/?api=1&query=138+Market+Street+CapitaGreen+Singapore+048946",
  phoneDisplay: "+65 6514 0710",
  phoneHref: "tel:+6565140710",
  csPhoneDisplay: "+65 3158 7515",
  csPhoneHref: "tel:+6531587515",
  emergencyDisplay: "+65 3158 2536",
  emergencyHref: "tel:+6531582536",
  email: "cs.sg@starrcompanies.com",
  hours: "Monday to Friday, 9:00am–12:30pm and 1:30pm–5:00pm",
  hoursNote: "Closed on Saturdays, Sundays and public holidays",
  ceo: "Sean Chuan Chen",
  regulator: "Monetary Authority of Singapore",
  license: "Direct Insurer (General)",
  parent: "Starr Insurance & Reinsurance Limited",
} as const;

export const NAV = [
  { to: "/solutions", label: "Solutions" },
  { to: "/travel", label: "Travel" },
  { to: "/claims", label: "Claims" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export const STATS = [
  { value: "100+", label: "Years of Starr heritage" },
  { value: "A", label: "A.M. Best rating (Excellent)" },
  { value: "170+", label: "Countries of reach" },
  { value: "388%", label: "Capital adequacy ratio" },
] as const;

export type LineOfBusiness = {
  slug: string;
  number: string;
  title: string;
  short: string;
  summary: string;
  image: string;
  imageAlt: string;
  who: string;
  coverages: string[];
  differentiators: string[];
};

export const LINES: LineOfBusiness[] = [
  {
    slug: "accident-health",
    number: "01",
    title: "Accident & Health",
    short: "Personal accident, medical and travel programmes for people on the move.",
    summary:
      "We underwrite accident and health risks for corporates, affinity groups and individuals — from business travel and personal accident to the Travelead retail travel product that Singapore travellers already know.",
    image: "/images/health.jpg",
    imageAlt: "Sunlit atrium of a private medical centre",
    who: "Employers, affinity partners, travel agents and individuals seeking medical and accident protection.",
    coverages: [
      "Personal accident and disablement",
      "Group and individual travel medical",
      "Business travel and expatriate programmes",
      "Travelead single-trip and annual travel plans",
      "Emergency medical evacuation and repatriation",
    ],
    differentiators: [
      "24-hour global emergency assistance hotline",
      "No co-payment or deductible on selected Travelead plans",
      "Hazardous sports covered for amateurs, without height or depth restrictions",
      "Follow-up medical treatment in Singapore after return",
    ],
  },
  {
    slug: "casualty",
    number: "02",
    title: "Casualty",
    short: "Liability capacity for companies that operate across borders and supply chains.",
    summary:
      "Casualty underwriting for Singapore and regional risks, with access to Starr’s international network. We look for well-managed insureds, clear contracts and a risk culture that matches our appetite.",
    image: "/images/skyline.jpg",
    imageAlt: "Singapore financial district at dusk across the water",
    who: "Brokers placing general liability, excess liability and related casualty lines for commercial clients.",
    coverages: [
      "Public and products liability",
      "Excess and umbrella liability",
      "Employers’ liability where applicable",
      "Premises and operations liability",
      "Contractual liability extensions",
    ],
    differentiators: [
      "Local underwriting with multinational programme support",
      "Focus on underwriting profitability rather than volume",
      "Treaty and facultative reinsurance to protect capital",
    ],
  },
  {
    slug: "financial-lines",
    number: "03",
    title: "Financial Lines",
    short: "Directors, professionals and balance sheets — cover for decisions under scrutiny.",
    summary:
      "Financial lines for listed and private companies, financial institutions and professional firms. We underwrite the exposures that sit with boards, officers and advisors as regulation and litigation continue to evolve.",
    image: "/images/boardroom.jpg",
    imageAlt: "Quiet walnut boardroom overlooking the Singapore CBD",
    who: "Boards, professional services firms, financial institutions and their brokers.",
    coverages: [
      "Directors’ and officers’ liability",
      "Professional indemnity / errors & omissions",
      "Financial institution professional and crime lines",
      "Employment practices liability",
      "Cyber and privacy liability (where aligned to appetite)",
    ],
    differentiators: [
      "Specialty underwriters who read the filing, not only the proposal form",
      "Capacity that can sit alongside global Starr programmes",
      "Claims-aware wordings for complex professional risks",
    ],
  },
  {
    slug: "construction",
    number: "04",
    title: "Construction",
    short: "Project insurance for builders, principals and lenders on Singapore and regional works.",
    summary:
      "Construction is a core Starr specialty. We underwrite contractors’ all risks, erection all risks and related project covers for infrastructure, commercial and industrial developments — with delay in start-up considered where the risk is understood.",
    image: "/images/construction.jpg",
    imageAlt: "High-rise construction with tower cranes over Singapore",
    who: "Principals, contractors, project managers and project lenders working through appointed brokers.",
    coverages: [
      "Contractors’ all risks (CAR)",
      "Erection all risks (EAR)",
      "Delay in start-up / advanced loss of profits",
      "Plant and equipment",
      "Third-party liability for project sites",
    ],
    differentiators: [
      "Engineering-led underwriting, not form-filling",
      "Appetite for complex, well-supervised projects",
      "Ability to coordinate cover across Starr’s Asia-Pacific offices",
    ],
  },
  {
    slug: "technical-risks",
    number: "05",
    title: "Technical Risks",
    short: "Energy, power and engineered assets where the exposure is technical, not generic.",
    summary:
      "Technical Risk (Tech) underwriting for power, energy and engineered industrial assets. These are short- to medium-tailed property and engineering risks that reward inspection, loss control and precise wording.",
    image: "/images/technical.jpg",
    imageAlt: "Industrial energy facility at dusk",
    who: "Energy, power and industrial insureds, and the brokers who know those assets.",
    coverages: [
      "Power generation and utilities",
      "Onshore energy and processing",
      "Machinery breakdown and engineering",
      "Operational property for technical occupancies",
      "Business interruption associated with technical assets",
    ],
    differentiators: [
      "Specialty underwriters for technical occupancies",
      "Reinsurance security standards that protect the balance sheet",
      "A portfolio that is largely short-tailed, with property as a major class",
    ],
  },
  {
    slug: "marine",
    number: "06",
    title: "Marine",
    short: "Cargo, hull and marine liability for a city that still lives by the sea.",
    summary:
      "Singapore is a global maritime hub. Our marine underwriting covers cargo moving through the port, hull interests and marine liability — written with the discipline of a specialty carrier, not a commodity line.",
    image: "/images/marine.jpg",
    imageAlt: "Container ship at berth with Singapore skyline beyond",
    who: "Shippers, freight forwarders, shipowners, charterers and marine brokers.",
    coverages: [
      "Marine cargo, including project cargo",
      "Hull and machinery",
      "Marine liability and related P&I-adjacent covers",
      "Stock throughput",
      "Transit and storage extensions",
    ],
    differentiators: [
      "Written from a port city with regional branch support",
      "Cargo and hull appetite aligned to Starr’s global marine practice",
      "Claims handling that understands bills of lading, surveys and general average",
    ],
  },
];

export function getLine(slug: string) {
  return LINES.find((line) => line.slug === slug);
}

export const TRAVEL_PLANS = [
  {
    id: "essential",
    name: "Essential",
    blurb: "Core medical and assistance for straightforward trips.",
    medical: "S$100,000",
    cancellation: "S$5,000",
    baggage: "S$3,000",
    personalAccident: "S$50,000",
    sports: "Amateur sports included",
    multiplier: 1,
  },
  {
    id: "premier",
    name: "Premier",
    blurb: "Higher medical limits and trip disruption cover — our most requested plan.",
    medical: "S$500,000",
    cancellation: "S$10,000",
    baggage: "S$5,000",
    personalAccident: "S$150,000",
    sports: "Amateur hazardous sports included",
    multiplier: 1.65,
    featured: true,
  },
  {
    id: "elite",
    name: "Elite",
    blurb: "High-limit medical, evacuation and family travel with no co-payment.",
    medical: "S$1,000,000",
    cancellation: "S$15,000",
    baggage: "S$8,000",
    personalAccident: "S$250,000",
    sports: "Amateur hazardous sports, no height/depth cap",
    multiplier: 2.35,
  },
] as const;

export const TRAVEL_FEATURES = [
  {
    title: "No age cap on single trips",
    body: "Single-trip Travelead enrolment has no upper age limit. Annual plans enrol up to age 70 and may renew to 75.",
  },
  {
    title: "No co-payment, no deductible",
    body: "Selected plans require no co-payment or deductible, so the first dollar of a covered claim is not yours to fund.",
  },
  {
    title: "Medical without visit sublimits",
    body: "Inpatient and outpatient medical expenses are covered without a sublimit on outpatient visits — subject to the schedule of benefits.",
  },
  {
    title: "Hazardous sports, amateurs",
    body: "Skiing, scuba diving and hot-air ballooning are covered for amateurs, with no restriction on height or depth.",
  },
  {
    title: "Children travelling alone",
    body: "Children under 18 travelling independently can be covered — a practical answer for school trips and family logistics.",
  },
  {
    title: "Follow-up care in Singapore",
    body: "Necessary follow-up treatment within 30 days of return is reimbursable when first treatment was sought overseas.",
  },
] as const;

export const TRAVEL_FAQS = [
  {
    q: "How long can a trip be covered?",
    a: "Single-trip plans cover up to 180 consecutive calendar days. Annual plans cover trips of up to 90 consecutive calendar days each.",
  },
  {
    q: "Is there a 24-hour emergency number?",
    a: `Yes. Starr’s Global Emergency Assistance Service operates around the clock on ${COMPANY.emergencyDisplay}, covering travel assistance, medical assistance, evacuation, repatriation, hospital admission guarantee and compassionate visit.`,
  },
  {
    q: "When must I notify a claim?",
    a: "Written notice of a claim should be submitted within 30 days after an accident or other event that might give rise to a claim. Keep police reports, medical reports, travel documents, boarding passes and receipts.",
  },
  {
    q: "Can I submit a travel claim online?",
    a: "Eligible travel claims can be submitted through Starr’s eClaim service. This site will prepare your notice and document checklist; a member of the Singapore team will follow up with the formal claim path.",
  },
  {
    q: "Are these premiums a bindable quote?",
    a: "No. Figures shown in the quotation illustrator are indicative only and not an offer to bind. Cover is subject to underwriting, the policy wording and the schedule of benefits issued by Starr International Insurance (Singapore) Pte. Ltd.",
  },
] as const;

export const CLAIM_STEPS = [
  {
    n: "01",
    title: "Protect people and property",
    body: "Seek medical help or emergency assistance first. For travel medical emergencies, call the 24-hour hotline before arranging evacuation or admission where it is safe to do so.",
  },
  {
    n: "02",
    title: "Notify us promptly",
    body: "Give written notice within 30 days of the accident or event. Use the form on this page or call customer service during business hours.",
  },
  {
    n: "03",
    title: "Assemble the evidence",
    body: "Police reports, medical reports, invoices, travel documents, boarding passes, photographs and correspondence with third parties all help us assess the claim cleanly.",
  },
  {
    n: "04",
    title: "Assessment and settlement",
    body: "A claims handler will confirm coverage, request any further documents and keep you informed. Settlement follows the policy wording and schedule of benefits.",
  },
] as const;

export const CLAIM_DOCS = [
  { id: "id", label: "Identification and policy or certificate number" },
  { id: "notice", label: "Written description of what happened, with date, place and parties" },
  { id: "medical", label: "Medical reports, diagnoses and original invoices (if injury or illness)" },
  { id: "police", label: "Police or incident report (if theft, accident or third-party injury)" },
  { id: "travel", label: "Travel documents, boarding passes or e-tickets (travel claims)" },
  { id: "receipts", label: "Purchase receipts, repair quotes or evidence of ownership" },
  { id: "photos", label: "Photographs of damage, injury site or lost items" },
  { id: "other", label: "Any correspondence with airlines, hotels, contractors or claimants" },
] as const;

export const GOVERNANCE = [
  {
    title: "Board oversight",
    body: "The Singapore board comprises five members, a majority independent, with a non-executive Chairman. The Chairman and Chief Executive are separate roles. The board meets quarterly.",
  },
  {
    title: "Committees",
    body: "An Audit Committee (including all independent directors) oversees internal and external audit. An Investment Committee, including the CEO and Chief Investment Officer, oversees investment activity.",
  },
  {
    title: "Enterprise risk",
    body: "Risk management is integrated into daily operations through policies, capital adequacy monitoring, reinsurance security standards and an ERM framework aligned with the Starr group.",
  },
  {
    title: "Capital",
    body: "As at 31 December 2024 the capital adequacy ratio was 388%, in excess of MAS fund solvency and capital adequacy requirements. The company has operated at a profit for the past five years.",
  },
] as const;

export const APAC = [
  { city: "Singapore", role: "Head office — CapitaGreen" },
  { city: "Labuan", role: "Malaysia branch (licensed 2023)" },
  { city: "Seoul", role: "Korea branch (licensed 2024)" },
  { city: "GIFT City", role: "India IFSC branch (licensed 2025)" },
  { city: "Hong Kong", role: "Starr Asia regional office" },
  { city: "Shanghai", role: "China operations" },
] as const;
