export type EnquiryKind = "travel" | "commercial" | "claim" | "general";

export type Enquiry = {
  id: string;
  createdAt: string;
  kind: EnquiryKind;
  payload: Record<string, string>;
};

const KEY = "starr-sg-enquiries";

function readAll(): Enquiry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Enquiry[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveEnquiry(kind: EnquiryKind, payload: Record<string, string>): Enquiry {
  const enquiry: Enquiry = {
    id: `SG${Date.now().toString(36).toUpperCase()}`,
    createdAt: new Date().toISOString(),
    kind,
    payload,
  };
  const next = [enquiry, ...readAll()].slice(0, 40);
  localStorage.setItem(KEY, JSON.stringify(next));
  return enquiry;
}

export function listEnquiries(): Enquiry[] {
  return readAll();
}
