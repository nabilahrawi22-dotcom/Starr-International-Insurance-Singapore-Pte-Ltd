import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHero, SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { LINES } from "@/lib/site";

export const Route = createFileRoute("/solutions")({ component: SolutionsPage });

function SolutionsPage() {
  return (
    <SiteShell>
      <main id="main">
        <PageHero
          eyebrow="Solutions"
          title="Six specialty lines. One underwriting standard."
          lede="Accident & Health, Casualty, Financial Lines, Construction, Technical Risks and Marine — written from Singapore for risks that need more than a commodity wording."
          image="/images/boardroom.jpg"
          imageAlt="Boardroom overlooking the Singapore CBD"
        />
        <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
          <div className="space-y-16">
            {LINES.map((line, index) => (
              <article
                key={line.slug}
                className="grid items-center gap-8 md:grid-cols-2 md:gap-12"
              >
                <img
                  src={line.image}
                  alt={line.imageAlt}
                  className={`img-frame aspect-video w-full rounded-xl object-cover ${index % 2 === 1 ? "md:order-2" : ""}`}
                />
                <div className={index % 2 === 1 ? "md:order-1" : ""}>
                  <p className="text-xs tracking-[0.22em] text-muted">{line.number}</p>
                  <h2 className="mt-2 font-display text-4xl text-navy">{line.title}</h2>
                  <p className="mt-4 leading-relaxed text-muted">{line.summary}</p>
                  <Button asChild className="mt-6">
                    <Link to="/solutions/$slug" params={{ slug: line.slug }}>
                      Read this line
                    </Link>
                  </Button>
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>
    </SiteShell>
  );
}
