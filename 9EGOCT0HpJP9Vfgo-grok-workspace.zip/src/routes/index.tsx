import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Phone } from "lucide-react";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { COMPANY, LINES, STATS } from "@/lib/site";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <SiteShell>
      <main id="main">
        <section className="relative isolate min-h-[36rem] overflow-hidden bg-navy text-ivory md:min-h-[42rem]">
          <img
            src="/images/hero-capitagreen.jpg"
            alt="CapitaGreen in Singapore’s Raffles Place at dusk"
            className="absolute inset-0 size-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-deep/94 via-navy-deep/78 to-navy/35" />
          <div className="relative mx-auto flex min-h-[36rem] max-w-6xl flex-col justify-end px-6 py-20 md:min-h-[42rem]">
            <p className="text-xs font-medium uppercase tracking-[0.28em] text-ivory/70">
              Singapore · CapitaGreen
            </p>
            <h1 className="mt-4 max-w-3xl font-display text-5xl font-medium text-ivory md:text-7xl">
              Meet the moment with specialty insurance.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-ivory/80">
              {COMPANY.shortName} underwrites accident & health, casualty, financial lines,
              construction, technical risks and marine — with local expertise and Starr’s global
              capacity behind every risk.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="inverse" size="lg">
                <Link to="/quote">Request a quotation</Link>
              </Button>
              <Button asChild variant="ghost" size="lg" className="border border-ivory/30">
                <Link to="/travel">Travelead travel cover</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="border-b border-line bg-navy text-ivory">
          <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-6 py-10 md:grid-cols-4">
            {STATS.map((stat) => (
              <div key={stat.label}>
                <p className="font-display text-4xl text-ivory md:text-5xl">{stat.value}</p>
                <p className="mt-2 text-sm text-ivory/65">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 md:grid-cols-2 md:py-28">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.24em] text-muted">The house</p>
            <h2 className="mt-3 font-display text-4xl text-navy md:text-5xl">
              A licensed Singapore insurer, not a storefront.
            </h2>
            <p className="mt-6 text-lg leading-relaxed text-muted">
              We operate from the seventh floor of CapitaGreen as a MAS-licensed Direct Insurer
              (General). Commercial programmes are placed through brokers. Individuals come to us
              for Travelead travel insurance, claims support and 24-hour emergency assistance.
            </p>
            <p className="mt-4 leading-relaxed text-muted">
              The Singapore office is also Starr’s hub for Labuan, Korea and GIFT City branches —
              underwriting, claims and management for a growing Asia-Pacific network.
            </p>
            <Button asChild className="mt-8" size="lg">
              <Link to="/about">
                About Starr Singapore <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
          <figure>
            <img
              src="/images/team.jpg"
              alt="Starr colleagues in a contemporary office reception"
              className="img-frame aspect-video w-full rounded-xl object-cover"
            />
            <figcaption className="mt-3 text-sm text-muted">
              Underwriting, claims and management — a specialist team, not a retail counter.
            </figcaption>
          </figure>
        </section>

        <section className="bg-ivory">
          <div className="mx-auto max-w-6xl px-6 py-20 md:py-28">
            <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
              <div>
                <p className="text-xs font-medium uppercase tracking-[0.24em] text-muted">
                  Lines of business
                </p>
                <h2 className="mt-3 max-w-xl font-display text-4xl text-navy md:text-5xl">
                  Specialty cover, written with discipline.
                </h2>
              </div>
              <Link
                to="/solutions"
                className="inline-flex min-h-11 items-center gap-2 text-sm font-medium text-navy"
              >
                View all solutions <ArrowRight className="size-4" />
              </Link>
            </div>
            <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {LINES.map((line) => (
                <Link
                  key={line.slug}
                  to="/solutions/$slug"
                  params={{ slug: line.slug }}
                  className="group overflow-hidden rounded-xl bg-paper shadow-card transition-shadow duration-200 hover:shadow-lift"
                >
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={line.image}
                      alt={line.imageAlt}
                      className="size-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <p className="text-xs tracking-[0.2em] text-muted">{line.number}</p>
                    <h3 className="mt-2 font-display text-2xl text-navy">{line.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted">{line.short}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="relative isolate overflow-hidden bg-navy text-ivory">
          <img
            src="/images/travel.jpg"
            alt="Traveller watching a departure at dawn"
            className="absolute inset-0 size-full object-cover opacity-50"
          />
          <div className="absolute inset-0 bg-navy-deep/70" />
          <div className="relative mx-auto grid max-w-6xl gap-10 px-6 py-20 md:grid-cols-2 md:items-center md:py-28">
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.24em] text-ivory/65">
                For travellers
              </p>
              <h2 className="mt-3 font-display text-4xl md:text-5xl">Travelead travel insurance</h2>
              <p className="mt-5 text-lg leading-relaxed text-ivory/80">
                Single-trip cover with no enrolment age limit. Annual plans to age 70. No
                co-payment on selected plans, amateur hazardous sports included, and 24-hour global
                assistance on {COMPANY.emergencyDisplay}.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button asChild variant="inverse" size="lg">
                  <Link to="/travel">Compare plans</Link>
                </Button>
                <Button asChild variant="ghost" size="lg" className="border border-ivory/30">
                  <Link to="/claims">How to claim</Link>
                </Button>
              </div>
            </div>
            <ul className="space-y-4 text-sm text-ivory/85">
              {[
                "Medical expenses without outpatient visit sublimits",
                "Follow-up treatment in Singapore within 30 days of return",
                "Children under 18 travelling alone can be covered",
                "Written notice of claim within 30 days of the event",
              ].map((item) => (
                <li key={item} className="border-t border-ivory/20 pt-4">
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="mx-auto grid max-w-6xl gap-10 px-6 py-20 md:grid-cols-2 md:py-28">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.24em] text-muted">CapitaGreen</p>
            <h2 className="mt-3 font-display text-4xl text-navy">Speak with the Singapore office</h2>
            <p className="mt-5 leading-relaxed text-muted">
              Brokers, risk managers and policyholders — the same address, two paths. Commercial
              placing through professional intermediaries; travel and claims with a direct customer
              service desk.
            </p>
            <address className="mt-6 not-italic text-ink">
              {COMPANY.addressLines.join(", ")}
            </address>
            <p className="mt-2 text-sm text-muted">{COMPANY.hours}</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <a href={COMPANY.phoneHref}>
                  <Phone className="size-4" /> {COMPANY.phoneDisplay}
                </a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/contact">Contact & hours</Link>
              </Button>
            </div>
          </div>
          <img
            src="/images/skyline.jpg"
            alt="Marina Bay and Raffles Place at dusk"
            className="img-frame h-full min-h-72 w-full rounded-xl object-cover"
          />
        </section>
      </main>
    </SiteShell>
  );
}
