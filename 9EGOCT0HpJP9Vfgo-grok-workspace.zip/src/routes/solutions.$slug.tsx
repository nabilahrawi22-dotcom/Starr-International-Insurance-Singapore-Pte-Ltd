import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { PageHero, SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { getLine, LINES } from "@/lib/site";

export const Route = createFileRoute("/solutions/$slug")({
  loader: ({ params }) => {
    const line = getLine(params.slug);
    if (!line) throw notFound();
    return line;
  },
  component: SolutionDetail,
});

function SolutionDetail() {
  const line = Route.useLoaderData();
  const others = LINES.filter((l) => l.slug !== line.slug);

  return (
    <SiteShell>
      <main id="main">
        <PageHero
          eyebrow={`Solutions · ${line.number}`}
          title={line.title}
          lede={line.short}
          image={line.image}
          imageAlt={line.imageAlt}
        />
        <section className="mx-auto grid max-w-6xl gap-12 px-6 py-16 md:grid-cols-12 md:py-24">
          <div className="md:col-span-7">
            <h2 className="font-display text-3xl text-navy">The appetite</h2>
            <p className="mt-4 text-lg leading-relaxed text-muted">{line.summary}</p>
            <p className="mt-4 leading-relaxed text-muted">{line.who}</p>
            <Button asChild className="mt-8" size="lg">
              <Link to="/quote">Request a quotation</Link>
            </Button>
          </div>
          <aside className="md:col-span-5">
            <div className="rounded-xl bg-ivory p-6">
              <h3 className="font-display text-2xl text-navy">Typical covers</h3>
              <ul className="mt-4 space-y-3">
                {line.coverages.map((item) => (
                  <li key={item} className="border-t border-line pt-3 text-sm text-ink">
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </section>
        <section className="bg-navy text-ivory">
          <div className="mx-auto max-w-6xl px-6 py-16 md:py-20">
            <h2 className="font-display text-3xl">Why brokers bring this to Starr</h2>
            <ul className="mt-8 grid gap-6 md:grid-cols-3">
              {line.differentiators.map((item) => (
                <li key={item} className="border-t border-ivory/20 pt-5 text-ivory/85">
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </section>
        <section className="mx-auto max-w-6xl px-6 py-16">
          <p className="text-xs uppercase tracking-[0.22em] text-muted">Also written here</p>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {others.map((other) => (
              <Link
                key={other.slug}
                to="/solutions/$slug"
                params={{ slug: other.slug }}
                className="rounded-xl border border-line bg-paper p-5 hover:shadow-card"
              >
                <p className="text-xs text-muted">{other.number}</p>
                <p className="mt-1 font-display text-xl text-navy">{other.title}</p>
              </Link>
            ))}
          </div>
        </section>
      </main>
    </SiteShell>
  );
}
