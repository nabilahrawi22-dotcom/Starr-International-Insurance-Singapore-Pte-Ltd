import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHero, SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { APAC, COMPANY, GOVERNANCE, STATS } from "@/lib/site";

export const Route = createFileRoute("/about")({ component: AboutPage });

function AboutPage() {
  return (
    <SiteShell>
      <main id="main">
        <PageHero
          eyebrow="Who we are"
          title="A Singapore insurer in a global specialty house."
          lede="Starr International Insurance (Singapore) Pte. Ltd. is a wholly owned subsidiary of Starr Insurance & Reinsurance Limited, itself an indirect subsidiary of Starr International Company, Inc."
          image="/images/skyline.jpg"
          imageAlt="Singapore financial district at dusk"
        />

        <section className="mx-auto grid max-w-6xl items-start gap-12 px-6 py-20 md:grid-cols-2 md:py-28">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.24em] text-muted">Mandate</p>
            <h2 className="mt-3 font-display text-4xl text-navy">
              Underwriting profitability, not volume for its own sake.
            </h2>
            <p className="mt-6 leading-relaxed text-muted">
              The Singapore company’s strategic objective is sustained profitability and capital
              efficiency. That means a balanced book, underwriting guidelines that are actually
              followed, prudent claims provisions, and reinsurers chosen for security rather than
              price alone.
            </p>
            <p className="mt-4 leading-relaxed text-muted">
              We are licensed by the Monetary Authority of Singapore as a Direct Insurer (General).
              The office at 138 Market Street, #07-04 CapitaGreen, houses local underwriting,
              claims and management — and supports overseas branches in Labuan, Seoul and GIFT City.
            </p>
          </div>
          <div className="rounded-xl bg-navy p-8 text-ivory md:p-10">
            <p className="text-xs uppercase tracking-[0.24em] text-ivory/60">Leadership</p>
            <p className="mt-4 font-display text-3xl">{COMPANY.ceo}</p>
            <p className="mt-1 text-sm text-ivory/70">Chief Executive, Singapore</p>
            <p className="mt-6 leading-relaxed text-ivory/80">
              The Singapore operation is led by {COMPANY.ceo}, as recorded in the MAS financial
              institutions directory. The Chairman and Chief Executive are separate offices. A
              Senior Management Committee covers underwriting, claims, finance, legal and
              compliance, risk, technology and people.
            </p>
          </div>
        </section>

        <section className="bg-ivory">
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 md:grid-cols-2 md:py-28">
            <img
              src="/images/leadership.jpg"
              alt="Starr Insurance corporate leadership"
              className="img-frame w-full rounded-xl object-cover"
            />
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.24em] text-muted">
                Starr group
              </p>
              <h2 className="mt-3 font-display text-4xl text-navy">
                A century of specialty insurance, written locally.
              </h2>
              <p className="mt-5 leading-relaxed text-muted">
                Starr traces its heritage to C.V. Starr’s founding of an insurance agency in
                Shanghai in 1919. Today the group writes in more than 170 countries, with an
                innovation mindset, an agile approach, and local teams wherever clients operate.
              </p>
              <p className="mt-4 leading-relaxed text-muted">
                Starr International Insurance (Singapore) Pte. Ltd. carries an A.M. Best rating of
                “A” (Excellent), Financial Size Category XV — the same financial strength
                designation as Starr’s other principal carriers.
              </p>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 py-20 md:py-28">
          <p className="text-xs font-medium uppercase tracking-[0.24em] text-muted">Governance</p>
          <h2 className="mt-3 max-w-2xl font-display text-4xl text-navy">
            Board oversight, internal control, enterprise risk.
          </h2>
          <div className="mt-12 grid gap-6 md:grid-cols-2">
            {GOVERNANCE.map((item) => (
              <article key={item.title} className="rounded-xl border border-line bg-paper p-6">
                <h3 className="font-display text-2xl text-navy">{item.title}</h3>
                <p className="mt-3 leading-relaxed text-muted">{item.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="border-y border-line bg-navy text-ivory">
          <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-6 py-12 md:grid-cols-4">
            {STATS.map((stat) => (
              <div key={stat.label}>
                <p className="font-display text-4xl">{stat.value}</p>
                <p className="mt-2 text-sm text-ivory/65">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 py-20 md:py-28">
          <p className="text-xs font-medium uppercase tracking-[0.24em] text-muted">
            Asia-Pacific
          </p>
          <h2 className="mt-3 font-display text-4xl text-navy">A regional network from Singapore</h2>
          <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {APAC.map((office) => (
              <li key={office.city} className="rounded-xl bg-ivory px-5 py-6">
                <p className="font-display text-2xl text-navy">{office.city}</p>
                <p className="mt-1 text-sm text-muted">{office.role}</p>
              </li>
            ))}
          </ul>
          <p className="mt-10 max-w-2xl text-sm leading-relaxed text-muted">
            For the financial year ended 31 December 2025, insurance revenue was approximately
            USD 424 million. The insurance service result was around USD 44 million. These figures
            are drawn from the company’s public disclosure and are presented here for context, not
            as a solicitation.
          </p>
          <Button asChild className="mt-8" size="lg">
            <Link to="/contact">Contact the Singapore office</Link>
          </Button>
        </section>
      </main>
    </SiteShell>
  );
}
