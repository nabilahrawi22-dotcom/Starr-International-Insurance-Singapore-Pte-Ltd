import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { TravelQuoteForm } from "@/components/quote-forms";
import { PageHero, SiteShell } from "@/components/site-shell";
import { COMPANY, TRAVEL_FAQS, TRAVEL_FEATURES, TRAVEL_PLANS } from "@/lib/site";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/travel")({ component: TravelPage });

function TravelPage() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <SiteShell>
      <main id="main">
        <PageHero
          eyebrow="Travelead"
          title="Travel insurance, written with honesty and a clear schedule."
          lede="Single-trip or annual. Medical, cancellation, baggage and 24-hour assistance — with no co-payment on selected plans."
          image="/images/travel.jpg"
          imageAlt="Traveller at the window as a flight departs"
        />

        <section className="border-b border-line bg-navy text-ivory">
          <div className="mx-auto flex max-w-6xl flex-col gap-3 px-6 py-5 md:flex-row md:items-center md:justify-between">
            <p className="text-sm">
              24-hour Global Emergency Assistance ·{" "}
              <a href={COMPANY.emergencyHref} className="font-medium text-ivory underline-offset-4 hover:underline">
                {COMPANY.emergencyDisplay}
              </a>
            </p>
            <p className="text-sm text-ivory/70">Customer service {COMPANY.csPhoneDisplay}</p>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
          <p className="text-xs font-medium uppercase tracking-[0.24em] text-muted">Why Travelead</p>
          <h2 className="mt-3 max-w-2xl font-display text-4xl text-navy">
            Built for how people actually travel from Singapore.
          </h2>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {TRAVEL_FEATURES.map((item) => (
              <article key={item.title} className="rounded-xl bg-ivory p-6">
                <h3 className="font-display text-2xl text-navy">{item.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted">{item.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="bg-paper">
          <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
            <h2 className="font-display text-4xl text-navy">Compare plans</h2>
            <p className="mt-3 max-w-2xl text-muted">
              Benefit amounts below illustrate typical Travelead-style schedules. Your issued
              policy wording and schedule of benefits prevail. Premiums in the illustrator are
              indicative only.
            </p>
            <div className="mt-10 overflow-x-auto">
              <table className="w-full min-w-3xl border-collapse text-left text-sm">
                <thead>
                  <tr className="border-b border-line">
                    <th className="py-4 pr-4 font-medium text-muted">Benefit</th>
                    {TRAVEL_PLANS.map((plan) => (
                      <th key={plan.id} className="px-4 py-4 font-display text-xl font-medium text-navy">
                        {plan.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(
                    [
                      ["Medical expenses", "medical"],
                      ["Trip cancellation", "cancellation"],
                      ["Baggage", "baggage"],
                      ["Personal accident", "personalAccident"],
                      ["Sports", "sports"],
                    ] as const
                  ).map(([label, key]) => (
                    <tr key={key} className="border-b border-line">
                      <td className="py-4 pr-4 text-muted">{label}</td>
                      {TRAVEL_PLANS.map((plan) => (
                        <td key={plan.id} className="px-4 py-4 text-ink">
                          {plan[key]}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        <section className="bg-ivory">
          <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
            <h2 className="font-display text-4xl text-navy">Illustrate a premium, then request a quote</h2>
            <p className="mt-3 max-w-2xl text-muted">
              Choose trip type, destination and plan. We will send a formal quotation — nothing on
              this page binds cover.
            </p>
            <div className="mt-10 rounded-xl bg-paper p-6 shadow-card md:p-10">
              <TravelQuoteForm />
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-3xl px-6 py-16 md:py-24">
          <h2 className="font-display text-4xl text-navy">Questions</h2>
          <ul className="mt-8 divide-y divide-line border-y border-line">
            {TRAVEL_FAQS.map((faq, i) => (
              <li key={faq.q}>
                <button
                  type="button"
                  className="flex min-h-14 w-full items-center justify-between gap-4 py-4 text-left"
                  aria-expanded={open === i}
                  onClick={() => setOpen(open === i ? null : i)}
                >
                  <span className="font-medium text-navy">{faq.q}</span>
                  <span className={cn("text-muted", open === i && "text-navy")}>
                    {open === i ? "−" : "+"}
                  </span>
                </button>
                {open === i ? (
                  <p className="pb-5 leading-relaxed text-muted">{faq.a}</p>
                ) : null}
              </li>
            ))}
          </ul>
        </section>
      </main>
    </SiteShell>
  );
}
