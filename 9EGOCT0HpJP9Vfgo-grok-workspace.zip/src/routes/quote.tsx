import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CommercialQuoteForm, TravelQuoteForm } from "@/components/quote-forms";
import { PageHero, SiteShell } from "@/components/site-shell";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/quote")({ component: QuotePage });

function QuotePage() {
  const [tab, setTab] = useState<"travel" | "commercial">("travel");

  return (
    <SiteShell>
      <main id="main">
        <PageHero
          eyebrow="Quotations"
          title="Tell us the risk. We will tell you if it is ours to write."
          lede="Travel quotations for individuals. Commercial submissions through — or copied to — your broker. Nothing on this page is an offer to bind."
          image="/images/boardroom.jpg"
          imageAlt="Boardroom in late afternoon light"
          compact
        />
        <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
          <div className="flex gap-3">
            {(
              [
                ["travel", "Travel"],
                ["commercial", "Commercial / broker"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className={cn(
                  "h-11 rounded-md px-5 text-sm font-medium transition-colors duration-150",
                  tab === id ? "bg-navy text-ivory" : "border border-line bg-paper text-ink",
                )}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="mt-10 rounded-xl bg-ivory p-6 md:p-10">
            {tab === "travel" ? <TravelQuoteForm /> : <CommercialQuoteForm />}
          </div>
        </section>
      </main>
    </SiteShell>
  );
}
