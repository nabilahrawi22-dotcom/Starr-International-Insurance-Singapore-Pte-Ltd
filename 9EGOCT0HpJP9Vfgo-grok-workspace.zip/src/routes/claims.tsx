import { createFileRoute } from "@tanstack/react-router";
import { Phone } from "lucide-react";
import { ClaimForm } from "@/components/quote-forms";
import { PageHero, SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { CLAIM_DOCS, CLAIM_STEPS, COMPANY } from "@/lib/site";

export const Route = createFileRoute("/claims")({ component: ClaimsPage });

function ClaimsPage() {
  return (
    <SiteShell>
      <main id="main">
        <PageHero
          eyebrow="Claims"
          title="When something happens, start with people. Then notify us."
          lede="Written notice within 30 days. Original documents. A handler who will tell you what happens next."
          image="/images/health.jpg"
          imageAlt="Quiet medical atrium"
        />

        <section className="bg-navy text-ivory">
          <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6 py-8 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.22em] text-ivory/60">Emergency</p>
              <p className="mt-1 font-display text-3xl">24-hour global assistance</p>
              <p className="mt-1 text-ivory/75">
                Travel, medical, evacuation, repatriation, hospital admission guarantee.
              </p>
            </div>
            <Button asChild variant="inverse" size="lg">
              <a href={COMPANY.emergencyHref}>
                <Phone className="size-4" /> {COMPANY.emergencyDisplay}
              </a>
            </Button>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
          <h2 className="font-display text-4xl text-navy">How a claim proceeds</h2>
          <ol className="mt-12 grid gap-6 md:grid-cols-2">
            {CLAIM_STEPS.map((step) => (
              <li key={step.n} className="rounded-xl border border-line bg-paper p-6">
                <p className="text-xs tracking-[0.22em] text-muted">{step.n}</p>
                <h3 className="mt-2 font-display text-2xl text-navy">{step.title}</h3>
                <p className="mt-3 leading-relaxed text-muted">{step.body}</p>
              </li>
            ))}
          </ol>
        </section>

        <section className="bg-ivory">
          <div className="mx-auto grid max-w-6xl gap-12 px-6 py-16 md:grid-cols-2 md:py-24">
            <div>
              <h2 className="font-display text-4xl text-navy">Documents that help</h2>
              <p className="mt-4 leading-relaxed text-muted">
                You do not need every item before you notify us. Tick what you already have — we
                will request the rest.
              </p>
              <ul className="mt-8 space-y-3">
                {CLAIM_DOCS.map((doc) => (
                  <li key={doc.id} className="border-t border-line pt-3 text-sm text-ink">
                    {doc.label}
                  </li>
                ))}
              </ul>
              <p className="mt-8 text-sm text-muted">
                Customer service {COMPANY.csPhoneDisplay} · {COMPANY.email} · {COMPANY.hours}
              </p>
            </div>
            <div className="rounded-xl bg-paper p-6 shadow-card md:p-8">
              <h3 className="font-display text-3xl text-navy">Notice of claim</h3>
              <p className="mt-2 mb-8 text-sm text-muted">
                This records a notice with the Singapore office. It does not replace a completed
                claim form or original evidence.
              </p>
              <ClaimForm />
            </div>
          </div>
        </section>
      </main>
    </SiteShell>
  );
}
