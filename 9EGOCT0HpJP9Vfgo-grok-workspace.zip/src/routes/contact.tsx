import { createFileRoute } from "@tanstack/react-router";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { ContactForm } from "@/components/quote-forms";
import { PageHero, SiteShell } from "@/components/site-shell";
import { COMPANY } from "@/lib/site";

export const Route = createFileRoute("/contact")({ component: ContactPage });

function ContactPage() {
  return (
    <SiteShell>
      <main id="main">
        <PageHero
          eyebrow="Contact"
          title="CapitaGreen, seventh floor."
          lede="138 Market Street is a corporate underwriting office. Appointments are preferred; travel and claims support is available by phone and email during business hours."
          image="/images/hero-capitagreen.jpg"
          imageAlt="CapitaGreen at dusk in Raffles Place"
        />

        <section className="mx-auto grid max-w-6xl gap-12 px-6 py-16 md:grid-cols-2 md:py-24">
          <div>
            <h2 className="font-display text-4xl text-navy">Singapore office</h2>
            <ul className="mt-8 space-y-6">
              <li className="flex gap-4">
                <MapPin className="mt-1 size-5 shrink-0 text-navy" strokeWidth={1.5} />
                <div>
                  <p className="font-medium text-ink">{COMPANY.name}</p>
                  <p className="text-muted">{COMPANY.addressLines.join(", ")}</p>
                  <a
                    href={COMPANY.mapsUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-1 inline-block text-sm font-medium text-navy"
                  >
                    Get directions
                  </a>
                </div>
              </li>
              <li className="flex gap-4">
                <Phone className="mt-1 size-5 shrink-0 text-navy" strokeWidth={1.5} />
                <div>
                  <p className="text-sm text-muted">Switchboard</p>
                  <a href={COMPANY.phoneHref} className="font-medium text-ink">
                    {COMPANY.phoneDisplay}
                  </a>
                  <p className="mt-2 text-sm text-muted">Customer service</p>
                  <a href={COMPANY.csPhoneHref} className="font-medium text-ink">
                    {COMPANY.csPhoneDisplay}
                  </a>
                  <p className="mt-2 text-sm text-muted">24-hour assistance</p>
                  <a href={COMPANY.emergencyHref} className="font-medium text-ink">
                    {COMPANY.emergencyDisplay}
                  </a>
                </div>
              </li>
              <li className="flex gap-4">
                <Mail className="mt-1 size-5 shrink-0 text-navy" strokeWidth={1.5} />
                <div>
                  <a href={`mailto:${COMPANY.email}`} className="font-medium text-ink">
                    {COMPANY.email}
                  </a>
                </div>
              </li>
              <li className="flex gap-4">
                <Clock className="mt-1 size-5 shrink-0 text-navy" strokeWidth={1.5} />
                <div>
                  <p className="font-medium text-ink">{COMPANY.hours}</p>
                  <p className="text-sm text-muted">{COMPANY.hoursNote}</p>
                </div>
              </li>
            </ul>
          </div>
          <div className="rounded-xl bg-ivory p-6 md:p-8">
            <h2 className="font-display text-3xl text-navy">Write to us</h2>
            <p className="mt-2 mb-8 text-sm text-muted">
              For placing business, please copy your broker. For an existing claim, use the claims
              notice so it reaches a handler with a reference number.
            </p>
            <ContactForm />
          </div>
        </section>
      </main>
    </SiteShell>
  );
}
