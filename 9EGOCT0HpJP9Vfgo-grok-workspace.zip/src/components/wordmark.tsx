import { cn } from "@/lib/utils";

type WordmarkProps = {
  tone?: "light" | "dark";
  size?: "sm" | "md";
  className?: string;
};

export function Wordmark({ tone = "light", size = "md", className }: WordmarkProps) {
  const color = tone === "light" ? "text-ivory" : "text-navy";
  const rule = tone === "light" ? "bg-ivory/70" : "bg-navy/70";
  return (
    <span
      className={cn("flex flex-col items-start leading-none", color, className)}
      aria-label="Starr Insurance"
    >
      <span
        className={cn(
          "font-display font-semibold tracking-[0.18em]",
          size === "md" ? "text-xl" : "text-base",
        )}
      >
        STARR
      </span>
      <span className={cn("my-1 h-px w-full", rule)} />
      <span
        className={cn(
          "font-sans font-medium uppercase tracking-[0.28em] text-xs",
          size === "sm" && "text-xs scale-90 origin-left",
        )}
      >
        Insurance
      </span>
    </span>
  );
}
