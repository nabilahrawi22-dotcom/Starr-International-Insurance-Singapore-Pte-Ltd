import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Wordmark } from "@/components/wordmark";
import { COMPANY, NAV } from "@/lib/site";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="sticky top-0 z-40 bg-navy text-ivory">
      <div className="hidden border-b border-ivory/10 md:block">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-2 text-xs tracking-wide text-ivory/70">
          <p>Licensed by the MAS as a Direct Insurer (General)</p>
          <a
            href={COMPANY.emergencyHref}
            className="inline-flex items-center gap-2 text-ivory hover:text-ivory"
          >
            <Phone className="size-3.5" strokeWidth={1.75} />
            24-hour assistance {COMPANY.emergencyDisplay}
          </a>
        </div>
      </div>
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-6 py-4">
        <Link to="/" className="shrink-0" aria-label="Starr Insurance Singapore home">
          <Wordmark size="md" />
        </Link>
        <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary">
          {NAV.map((item) => {
            const active = pathname === item.to || pathname.startsWith(`${item.to}/`);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "relative text-sm tracking-wide text-ivory/75 transition-colors duration-150 hover:text-ivory",
                  active && "text-ivory",
                )}
              >
                {item.label}
                {active ? (
                  <span className="absolute -bottom-1 left-0 h-px w-full bg-ivory/80" />
                ) : null}
              </Link>
            );
          })}
        </nav>
        <div className="flex items-center gap-3">
          <Button asChild variant="inverse" size="sm" className="hidden sm:inline-flex">
            <Link to="/quote">Request a quotation</Link>
          </Button>
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-md text-ivory lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-6" /> : <Menu className="size-6" />}
          </button>
        </div>
      </div>
      {open ? (
        <div className="border-t border-ivory/10 bg-navy-deep lg:hidden">
          <nav className="mx-auto flex max-w-6xl flex-col px-6 py-4" aria-label="Mobile">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="flex min-h-11 items-center border-b border-ivory/10 text-base text-ivory"
              >
                {item.label}
              </Link>
            ))}
            <Link
              to="/quote"
              className="mt-4 flex min-h-11 items-center justify-center rounded-md bg-ivory text-sm font-medium text-navy"
            >
              Request a quotation
            </Link>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
