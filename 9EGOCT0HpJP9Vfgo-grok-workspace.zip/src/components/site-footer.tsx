import { Link } from "@tanstack/react-router";
import { Wordmark } from "@/components/wordmark";
import { COMPANY, LINES, NAV } from "@/lib/site";

export function SiteFooter() {
  return (
    <footer className="bg-navy-deep text-ivory">
      <div className="mx-auto grid max-w-6xl gap-12 px-6 py-16 md:grid-cols-4">
        <div className="md:col-span-1">
          <Wordmark />
          <p className="mt-6 max-w-xs text-sm leading-relaxed text-ivory/70">
            {COMPANY.name} is a Singapore-incorporated general insurer, licensed by the Monetary
            Authority of Singapore.
          </p>
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-ivory/50">Visit</p>
          <ul className="mt-4 space-y-2 text-sm text-ivory/80">
            {NAV.map((item) => (
              <li key={item.to}>
                <Link to={item.to} className="hover:text-ivory">
                  {item.label}
                </Link>
              </li>
            ))}
            <li>
              <Link to="/quote" className="hover:text-ivory">
                Request a quotation
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-ivory/50">Solutions</p>
          <ul className="mt-4 space-y-2 text-sm text-ivory/80">
            {LINES.map((line) => (
              <li key={line.slug}>
                <Link to="/solutions/$slug" params={{ slug: line.slug }} className="hover:text-ivory">
                  {line.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-ivory/50">Singapore</p>
          <address className="mt-4 not-italic text-sm leading-relaxed text-ivory/80">
            {COMPANY.addressLines.map((line) => (
              <span key={line} className="block">
                {line}
              </span>
            ))}
            <a href={COMPANY.phoneHref} className="mt-3 block hover:text-ivory">
              {COMPANY.phoneDisplay}
            </a>
            <a href={`mailto:${COMPANY.email}`} className="block hover:text-ivory">
              {COMPANY.email}
            </a>
          </address>
        </div>
      </div>
      <div className="border-t border-ivory/10">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-6 py-6 text-xs leading-relaxed text-ivory/50 md:flex-row md:items-start md:justify-between">
          <p>
            {COMPANY.name}. Licensed by the {COMPANY.regulator} as a {COMPANY.license}. Information
            on this site is general in nature and does not constitute an offer to bind insurance.
            Policy terms, conditions and exclusions in the issued wording prevail.
          </p>
          <p className="shrink-0">© {new Date().getFullYear()} Starr Insurance</p>
        </div>
      </div>
    </footer>
  );
}
