import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { FieldError, Input, Label, Select, Textarea } from "@/components/ui/input";
import { saveEnquiry } from "@/lib/enquiries";
import { LINES, TRAVEL_PLANS } from "@/lib/site";
import { cn } from "@/lib/utils";

function SuccessPanel({ children, className }: { children: ReactNode; className: string }) {
  const el = useRef<HTMLDivElement>(null);
  useEffect(() => {
    el.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, []);
  return (
    <div ref={el} className={className}>
      {children}
    </div>
  );
}

const REGIONS: { id: string; label: string; factor: number }[] = [
  { id: "asean", label: "ASEAN", factor: 1 },
  { id: "asia", label: "Asia (ex-Japan)", factor: 1.15 },
  { id: "worldwide", label: "Worldwide excluding USA / Canada", factor: 1.45 },
  { id: "usa", label: "Worldwide including USA / Canada", factor: 1.85 },
];

function formatSgd(value: number) {
  return new Intl.NumberFormat("en-SG", {
    style: "currency",
    currency: "SGD",
    maximumFractionDigits: 0,
  }).format(Math.round(value));
}

export function TravelQuoteForm({ compact = false }: { compact?: boolean }) {
  const [trip, setTrip] = useState<"single" | "annual">("single");
  const [region, setRegion] = useState(REGIONS[0].id);
  const [travellers, setTravellers] = useState(1);
  const [days, setDays] = useState(7);
  const [planId, setPlanId] = useState("premier");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [ref, setRef] = useState<string | null>(null);

  const estimate = useMemo(() => {
    const regionFactor = REGIONS.find((r) => r.id === region)?.factor ?? 1;
    const plan = TRAVEL_PLANS.find((p) => p.id === planId) ?? TRAVEL_PLANS[1];
    const base = trip === "annual" ? 188 : 52;
    const durationFactor = trip === "annual" ? 1 : 0.75 + Math.min(days, 180) / 120;
    const peopleFactor = 1 + Math.max(0, travellers - 1) * 0.72;
    return base * regionFactor * plan.multiplier * durationFactor * peopleFactor;
  }, [trip, region, travellers, days, planId]);

  function submit(e: FormEvent) {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!name.trim()) next.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email.";
    if (phone.replace(/\D/g, "").length < 8) next.phone = "Enter a contact number.";
    setErrors(next);
    if (Object.keys(next).length) return;

    const enquiry = saveEnquiry("travel", {
      trip,
      region,
      travellers: String(travellers),
      days: String(days),
      plan: planId,
      estimate: formatSgd(estimate),
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
    });
    setRef(enquiry.id);
    toast.success(`Quotation request ${enquiry.id} received.`);
  }

  if (ref) {
    return (
      <SuccessPanel className="rounded-xl bg-navy p-8 text-ivory shadow-card">
        <p className="text-xs uppercase tracking-[0.24em] text-ivory/60">Request received</p>
        <h3 className="mt-3 font-display text-3xl">Thank you. We have your details.</h3>
        <p className="mt-4 text-ivory/80">
          Reference <span className="font-medium text-ivory">{ref}</span>. A member of the Singapore
          team will follow up with a formal quotation. The illustrated premium of{" "}
          {formatSgd(estimate)} is indicative only and is not an offer to bind.
        </p>
      </SuccessPanel>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-8">
      <fieldset className="space-y-3">
        <legend className="text-xs font-medium uppercase tracking-[0.22em] text-muted">
          Trip type
        </legend>
        <div className="grid grid-cols-2 gap-3">
          {(
            [
              ["single", "Single trip"],
              ["annual", "Annual multi-trip"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTrip(id)}
              className={cn(
                "h-12 rounded-md border text-sm font-medium transition-colors duration-150",
                trip === id
                  ? "border-navy bg-navy text-ivory"
                  : "border-line bg-paper text-ink hover:border-navy",
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </fieldset>

      <div className={cn("grid gap-5", compact ? "md:grid-cols-2" : "md:grid-cols-3")}>
        <div>
          <Label htmlFor="region">Destination</Label>
          <Select id="region" value={region} onChange={(e) => setRegion(e.target.value)}>
            {REGIONS.map((r) => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </Select>
        </div>
        <div>
          <Label htmlFor="travellers">Travellers</Label>
          <Select
            id="travellers"
            value={String(travellers)}
            onChange={(e) => setTravellers(Number(e.target.value))}
          >
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </Select>
        </div>
        {trip === "single" ? (
          <div>
            <Label htmlFor="days">Duration (days)</Label>
            <Input
              id="days"
              type="number"
              min={1}
              max={180}
              value={days}
              onChange={(e) => setDays(Number(e.target.value) || 1)}
            />
          </div>
        ) : null}
      </div>

      <fieldset>
        <legend className="mb-3 text-xs font-medium uppercase tracking-[0.22em] text-muted">
          Plan
        </legend>
        <div className="grid gap-3 md:grid-cols-3">
          {TRAVEL_PLANS.map((plan) => (
            <button
              key={plan.id}
              type="button"
              onClick={() => setPlanId(plan.id)}
              className={cn(
                "rounded-xl border p-5 text-left transition-shadow duration-150",
                planId === plan.id
                  ? "border-navy bg-navy text-ivory shadow-lift"
                  : "border-line bg-paper text-ink hover:shadow-card",
              )}
            >
              <p className="font-display text-2xl">{plan.name}</p>
              <p
                className={cn(
                  "mt-2 text-sm leading-relaxed",
                  planId === plan.id ? "text-ivory/75" : "text-muted",
                )}
              >
                Medical {plan.medical}
              </p>
            </button>
          ))}
        </div>
      </fieldset>

      <div className="flex flex-col justify-between gap-4 rounded-xl bg-ivory p-6 md:flex-row md:items-end">
        <div>
          <p className="text-xs uppercase tracking-[0.22em] text-muted">Indicative premium</p>
          <p className="mt-1 font-display text-4xl text-navy">{formatSgd(estimate)}</p>
          <p className="mt-1 max-w-md text-sm text-muted">
            Illustration only — not a quotation or an offer to bind. Final terms follow underwriting
            and the policy wording.
          </p>
        </div>
      </div>

      <div className="grid gap-5 md:grid-cols-3">
        <div>
          <Label htmlFor="tq-name">Full name</Label>
          <Input id="tq-name" value={name} onChange={(e) => setName(e.target.value)} />
          <FieldError>{errors.name}</FieldError>
        </div>
        <div>
          <Label htmlFor="tq-email">Email</Label>
          <Input
            id="tq-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <FieldError>{errors.email}</FieldError>
        </div>
        <div>
          <Label htmlFor="tq-phone">Phone</Label>
          <Input id="tq-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <FieldError>{errors.phone}</FieldError>
        </div>
      </div>

      <Button type="submit" size="lg">
        Request a formal quotation
      </Button>
    </form>
  );
}

export function CommercialQuoteForm() {
  const [line, setLine] = useState(LINES[0].slug);
  const [company, setCompany] = useState("");
  const [turnover, setTurnover] = useState("25-100");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [ref, setRef] = useState<string | null>(null);

  function submit(e: FormEvent) {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!company.trim()) next.company = "Company name is required.";
    if (!name.trim()) next.name = "Please enter a contact name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email.";
    setErrors(next);
    if (Object.keys(next).length) return;
    const enquiry = saveEnquiry("commercial", {
      line,
      company: company.trim(),
      turnover,
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      notes: notes.trim(),
    });
    setRef(enquiry.id);
    toast.success(`Broker enquiry ${enquiry.id} received.`);
  }

  if (ref) {
    return (
      <SuccessPanel className="rounded-xl bg-navy p-8 text-ivory">
        <p className="text-xs uppercase tracking-[0.24em] text-ivory/60">Enquiry received</p>
        <h3 className="mt-3 font-display text-3xl">Your submission is with our underwriters.</h3>
        <p className="mt-4 text-ivory/80">
          Reference <span className="font-medium text-ivory">{ref}</span>. We typically respond
          through the placing broker. This is not a bindable indication.
        </p>
      </SuccessPanel>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="grid gap-5 md:grid-cols-2">
        <div>
          <Label htmlFor="line">Line of business</Label>
          <Select id="line" value={line} onChange={(e) => setLine(e.target.value)}>
            {LINES.map((l) => (
              <option key={l.slug} value={l.slug}>
                {l.title}
              </option>
            ))}
          </Select>
        </div>
        <div>
          <Label htmlFor="turnover">Approximate turnover (SGD)</Label>
          <Select id="turnover" value={turnover} onChange={(e) => setTurnover(e.target.value)}>
            <option value="under-25">Under 25 million</option>
            <option value="25-100">25 – 100 million</option>
            <option value="100-500">100 – 500 million</option>
            <option value="500+">Over 500 million</option>
          </Select>
        </div>
      </div>
      <div>
        <Label htmlFor="company">Company / insured</Label>
        <Input id="company" value={company} onChange={(e) => setCompany(e.target.value)} />
        <FieldError>{errors.company}</FieldError>
      </div>
      <div className="grid gap-5 md:grid-cols-3">
        <div>
          <Label htmlFor="cq-name">Contact name</Label>
          <Input id="cq-name" value={name} onChange={(e) => setName(e.target.value)} />
          <FieldError>{errors.name}</FieldError>
        </div>
        <div>
          <Label htmlFor="cq-email">Email</Label>
          <Input
            id="cq-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <FieldError>{errors.email}</FieldError>
        </div>
        <div>
          <Label htmlFor="cq-phone">Phone</Label>
          <Input id="cq-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </div>
      </div>
      <div>
        <Label htmlFor="notes">Risk notes</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Occupancy, geography, current programme, target inception…"
        />
      </div>
      <Button type="submit" size="lg">
        Submit to underwriting
      </Button>
    </form>
  );
}

export function ContactForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [topic, setTopic] = useState("general");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [ref, setRef] = useState<string | null>(null);

  function submit(e: FormEvent) {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!name.trim()) next.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email.";
    if (message.trim().length < 10) next.message = "Please tell us a little more.";
    setErrors(next);
    if (Object.keys(next).length) return;
    const enquiry = saveEnquiry("general", {
      name: name.trim(),
      email: email.trim(),
      topic,
      message: message.trim(),
    });
    setRef(enquiry.id);
    toast.success(`Message ${enquiry.id} sent.`);
  }

  if (ref) {
    return (
      <SuccessPanel className="rounded-xl border border-line bg-ivory p-8">
        <p className="text-xs uppercase tracking-[0.22em] text-muted">Message received</p>
        <h3 className="mt-2 font-display text-3xl text-navy">We will be in touch.</h3>
        <p className="mt-3 text-muted">
          Reference {ref}. During business hours we aim to respond the same day.
        </p>
      </SuccessPanel>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="grid gap-5 md:grid-cols-2">
        <div>
          <Label htmlFor="c-name">Name</Label>
          <Input id="c-name" value={name} onChange={(e) => setName(e.target.value)} />
          <FieldError>{errors.name}</FieldError>
        </div>
        <div>
          <Label htmlFor="c-email">Email</Label>
          <Input
            id="c-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <FieldError>{errors.email}</FieldError>
        </div>
      </div>
      <div>
        <Label htmlFor="topic">Topic</Label>
        <Select id="topic" value={topic} onChange={(e) => setTopic(e.target.value)}>
          <option value="general">General enquiry</option>
          <option value="policy">Existing policy</option>
          <option value="broker">Broker / placing</option>
          <option value="media">Media and public disclosure</option>
        </Select>
      </div>
      <div>
        <Label htmlFor="message">Message</Label>
        <Textarea id="message" value={message} onChange={(e) => setMessage(e.target.value)} />
        <FieldError>{errors.message}</FieldError>
      </div>
      <Button type="submit" size="lg">
        Send message
      </Button>
    </form>
  );
}

export function ClaimForm() {
  const [kind, setKind] = useState("travel");
  const [policy, setPolicy] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [incident, setIncident] = useState("");
  const [docs, setDocs] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [ref, setRef] = useState<string | null>(null);

  function toggleDoc(id: string) {
    setDocs((prev) => (prev.includes(id) ? prev.filter((d) => d !== id) : [...prev, id]));
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!name.trim()) next.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Enter a valid email.";
    if (incident.trim().length < 12) next.incident = "Please describe what happened.";
    setErrors(next);
    if (Object.keys(next).length) return;
    const enquiry = saveEnquiry("claim", {
      kind,
      policy: policy.trim(),
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      incident: incident.trim(),
      docs: docs.join(", "),
    });
    setRef(enquiry.id);
    toast.success(`Claim notice ${enquiry.id} recorded.`);
  }

  if (ref) {
    return (
      <SuccessPanel className="rounded-xl bg-navy p-8 text-ivory">
        <p className="text-xs uppercase tracking-[0.24em] text-ivory/60">Notice recorded</p>
        <h3 className="mt-3 font-display text-3xl">Your claim notice is with us.</h3>
        <p className="mt-4 leading-relaxed text-ivory/80">
          Reference <span className="font-medium text-ivory">{ref}</span>. Please keep original
          documents. A handler will contact you to complete the formal claim. For travel medical
          emergencies still in progress, call the 24-hour assistance line immediately.
        </p>
      </SuccessPanel>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      <div className="grid gap-5 md:grid-cols-2">
        <div>
          <Label htmlFor="kind">Claim type</Label>
          <Select id="kind" value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="travel">Travel (Travelead)</option>
            <option value="accident">Accident & Health</option>
            <option value="property">Property / technical</option>
            <option value="liability">Casualty / financial lines</option>
            <option value="marine">Marine</option>
            <option value="construction">Construction</option>
          </Select>
        </div>
        <div>
          <Label htmlFor="policy">Policy or certificate number (if known)</Label>
          <Input id="policy" value={policy} onChange={(e) => setPolicy(e.target.value)} />
        </div>
      </div>
      <div className="grid gap-5 md:grid-cols-3">
        <div>
          <Label htmlFor="cl-name">Name</Label>
          <Input id="cl-name" value={name} onChange={(e) => setName(e.target.value)} />
          <FieldError>{errors.name}</FieldError>
        </div>
        <div>
          <Label htmlFor="cl-email">Email</Label>
          <Input
            id="cl-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <FieldError>{errors.email}</FieldError>
        </div>
        <div>
          <Label htmlFor="cl-phone">Phone</Label>
          <Input id="cl-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </div>
      </div>
      <div>
        <Label htmlFor="incident">What happened</Label>
        <Textarea
          id="incident"
          value={incident}
          onChange={(e) => setIncident(e.target.value)}
          placeholder="Date, place, what occurred, and any third parties involved."
        />
        <FieldError>{errors.incident}</FieldError>
      </div>
      <fieldset>
        <legend className="mb-3 text-sm font-medium text-ink">Documents you can provide</legend>
        <ul className="grid gap-2 md:grid-cols-2">
          {[
            ["id", "Identification / policy number"],
            ["medical", "Medical reports and invoices"],
            ["police", "Police or incident report"],
            ["travel", "Tickets and boarding passes"],
            ["receipts", "Receipts or repair quotes"],
            ["photos", "Photographs"],
          ].map(([id, label]) => (
            <li key={id}>
              <label className="flex min-h-11 cursor-pointer items-center gap-3 rounded-md border border-line bg-paper px-3 text-sm">
                <input
                  type="checkbox"
                  checked={docs.includes(id)}
                  onChange={() => toggleDoc(id)}
                  className="size-4 accent-navy"
                />
                {label}
              </label>
            </li>
          ))}
        </ul>
      </fieldset>
      <Button type="submit" size="lg">
        Submit notice of claim
      </Button>
    </form>
  );
}
