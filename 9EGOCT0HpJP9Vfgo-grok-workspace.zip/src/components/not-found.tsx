import { Link } from "@tanstack/react-router";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";

export function NotFoundPage() {
  return (
    <SiteShell>
      <main id="main" className="mx-auto flex max-w-3xl flex-col px-6 py-24">
        <p className="text-xs uppercase tracking-[0.24em] text-muted">404</p>
        <h1 className="mt-3 font-display text-5xl text-navy">This page is not on our books.</h1>
        <p className="mt-4 max-w-md text-muted">
          The address may have changed, or the policy never existed. Return to the Singapore home
          office.
        </p>
        <Button asChild className="mt-8 w-fit" size="lg">
          <Link to="/">Back to home</Link>
        </Button>
      </main>
    </SiteShell>
  );
}
