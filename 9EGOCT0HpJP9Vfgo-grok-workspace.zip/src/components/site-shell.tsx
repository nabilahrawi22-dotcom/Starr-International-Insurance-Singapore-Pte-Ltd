import { useRouterState } from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { Toaster } from "sonner";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export function SiteShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }, [pathname]);

  return (
    <div className="flex min-h-dvh flex-col bg-paper text-ink">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-ivory focus:px-4 focus:py-2 focus:text-navy"
      >
        Skip to content
      </a>
      <SiteHeader />
      <div className="flex-1">{children}</div>
      <SiteFooter />
      <Toaster position="top-center" richColors={false} />
    </div>
  );
}

export function PageHero({
  eyebrow,
  title,
  lede,
  image,
  imageAlt,
  compact = false,
}: {
  eyebrow?: string;
  title: string;
  lede?: string;
  image: string;
  imageAlt: string;
  compact?: boolean;
}) {
  return (
    <section
      className={
        compact
          ? "relative isolate overflow-hidden bg-navy text-ivory"
          : "relative isolate min-h-[28rem] overflow-hidden bg-navy text-ivory md:min-h-[32rem]"
      }
    >
      <img src={image} alt={imageAlt} className="absolute inset-0 size-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-navy-deep/92 via-navy/78 to-navy/40" />
      <div
        className={
          compact
            ? "relative mx-auto flex max-w-6xl flex-col justify-end px-6 py-12 md:py-16"
            : "relative mx-auto flex min-h-[28rem] max-w-6xl flex-col justify-end px-6 py-16 md:min-h-[32rem] md:py-20"
        }
      >
        {eyebrow ? (
          <p className="text-xs font-medium uppercase tracking-[0.28em] text-ivory/70">{eyebrow}</p>
        ) : null}
        <h1 className="mt-3 max-w-3xl font-display text-5xl font-medium tracking-tight text-ivory md:text-6xl">
          {title}
        </h1>
        {lede ? <p className="mt-5 max-w-xl text-lg leading-relaxed text-ivory/80">{lede}</p> : null}
      </div>
    </section>
  );
}
